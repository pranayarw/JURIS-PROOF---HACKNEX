from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from ..database import get_db
from .. import models, schemas, auth_utils

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/signup", response_model=schemas.UserOut, status_code=status.HTTP_201_CREATED)
def signup(user_in: schemas.UserCreate, db: Session = Depends(get_db)):
    # Check if user already exists
    existing_user = db.query(models.User).filter(models.User.email == user_in.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account is already registered with this email address."
        )
        
    hashed_pwd = auth_utils.get_password_hash(user_in.password)
    # The first user registered in the prototype is an Admin for testing convenience, others are normal users
    user_count = db.query(models.User).count()
    role = "admin" if user_count == 0 else "user"
    
    new_user = models.User(
        email=user_in.email,
        hashed_password=hashed_pwd,
        role=role,
        two_factor_enabled=False
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Log the signup
    log = models.SystemLog(action=f"User registered: {new_user.email}")
    db.add(log)
    db.commit()
    
    return new_user

@router.post("/login", response_model=schemas.Token)
def login(user_in: schemas.UserLogin, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == user_in.email).first()
    if not user or not auth_utils.verify_password(user_in.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )
        
    # Generate token
    token_data = {"sub": user.email, "id": user.id, "role": user.role}
    access_token = auth_utils.create_access_token(data=token_data)
    
    # Log the login
    log = models.SystemLog(action=f"User logged in: {user.email}")
    db.add(log)
    db.commit()
    
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=schemas.UserOut)
def get_me(current_user: models.User = Depends(auth_utils.get_current_user)):
    return current_user

@router.put("/me", response_model=schemas.UserOut)
def update_me(user_update: schemas.UserUpdate, current_user: models.User = Depends(auth_utils.get_current_user), db: Session = Depends(get_db)):
    if user_update.email is not None:
        # Check if email is already taken
        other_user = db.query(models.User).filter(models.User.email == user_update.email, models.User.id != current_user.id).first()
        if other_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already in use."
            )
        current_user.email = user_update.email
        
    if user_update.two_factor_enabled is not None:
        current_user.two_factor_enabled = user_update.two_factor_enabled
        
    db.commit()
    db.refresh(current_user)
    
    # Log the update
    log = models.SystemLog(action=f"User updated profile details: {current_user.email}")
    db.add(log)
    db.commit()
    
    return current_user
