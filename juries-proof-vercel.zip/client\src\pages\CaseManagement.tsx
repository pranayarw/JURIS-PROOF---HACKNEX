import React, { useEffect, useState } from 'react';
import { Briefcase, Plus, Trash2, ShieldCheck, ArrowRight, FolderPlus } from 'lucide-react';
import { getCases, createCase, deleteCase, Case } from '../services/api';

interface CaseManagementProps {
  activeCase: Case | null;
  onSelectCase: (c: Case) => void;
  onNavigateTab: (tab: string) => void;
}

export const CaseManagementPage: React.FC<CaseManagementProps> = ({
  activeCase,
  onSelectCase,
  onNavigateTab
}) => {
  const [cases, setCases] = useState<Case[]>([]);
  const [showModal, setShowModal] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [caseType, setCaseType] = useState('Commercial / Contract');
  const [jurisdiction, setJurisdiction] = useState('High Court');
  const [description, setDescription] = useState('');
  const [parties, setParties] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadCases();
  }, []);

  const loadCases = async () => {
    try {
      const data = await getCases();
      setCases(data);
    } catch (err) {
      console.error('Failed to load cases:', err);
    }
  };

  const handleCreateCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('title', title);
      formData.append('case_type', caseType);
      formData.append('jurisdiction', jurisdiction);
      formData.append('description', description);
      formData.append('parties', parties);

      const newCase = await createCase(formData);
      setCases([newCase, ...cases]);
      onSelectCase(newCase);
      setShowModal(false);
      
      // Reset form
      setTitle('');
      setDescription('');
      setParties('');
    } catch (err) {
      alert('Failed to create case');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCase = async (id: number) => {
    if (!confirm('Are you sure you want to delete this case and all associated document evidence?')) return;
    try {
      await deleteCase(id);
      setCases(cases.filter((c) => c.id !== id));
    } catch (err) {
      alert('Failed to delete case');
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-blue-600" />
            <span>Case Workspace & Case Isolation</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Every case acts as an isolated workspace. Documents in Case A will never contaminate evidence in Case B.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow transition shrink-0"
        >
          <FolderPlus className="w-4 h-4" />
          <span>Create New Case</span>
        </button>
      </div>

      {/* Case Isolation Guarantee Alert */}
      <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 rounded-xl p-4 flex items-start space-x-3 text-xs text-blue-900 dark:text-blue-200">
        <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold block">Strict Case Isolation Standard</span>
          <span>All search, RAG Q&A, evidence graphs, contradiction detection, and legal drafting requests are explicitly scoped by <code className="bg-blue-100 dark:bg-blue-900 px-1 py-0.5 rounded font-mono">case_id</code> to guarantee non-contamination across different legal matters.</span>
        </div>
      </div>

      {/* Cases List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {cases.map((c) => {
          const isSelected = activeCase?.id === c.id;
          return (
            <div
              key={c.id}
              className={`bg-white dark:bg-slate-900 rounded-xl p-5 border shadow-sm transition flex flex-col justify-between ${
                isSelected 
                  ? 'border-blue-600 ring-2 ring-blue-500/20 dark:border-blue-500' 
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                    {c.case_number}
                  </span>
                  <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded text-[10px] font-bold">
                    {c.status}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-2 line-clamp-1">
                  {c.title}
                </h3>
                
                <p className="text-xs text-slate-500 line-clamp-2 mt-1 min-h-[32px]">
                  {c.description || 'No description provided for this case.'}
                </p>

                <div className="mt-4 space-y-1 text-xs text-slate-600 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800 pt-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Type:</span>
                    <span className="font-semibold">{c.case_type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Jurisdiction:</span>
                    <span className="font-semibold">{c.jurisdiction}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Evidence Coverage:</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">{c.evidence_coverage ?? 0}%</span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => handleDeleteCase(c.id)}
                  className="text-slate-400 hover:text-red-600 p-1.5 rounded transition"
                  title="Delete Case"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <button
                  onClick={() => {
                    onSelectCase(c);
                    onNavigateTab('documents');
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-blue-600 hover:text-white'
                  }`}
                >
                  <span>{isSelected ? 'Active Workspace' : 'Select Case'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Case Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <Plus className="w-5 h-5 text-blue-600" />
              <span>Create New Case Workspace</span>
            </h2>

            <form onSubmit={handleCreateCase} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Case Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apex Corp vs. Zenith Logistics Ltd"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Case Type</label>
                  <select
                    value={caseType}
                    onChange={(e) => setCaseType(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="Commercial / Contract">Commercial / Contract</option>
                    <option value="Criminal Defense">Criminal Defense</option>
                    <option value="Intellectual Property">Intellectual Property</option>
                    <option value="Civil Litigation">Civil Litigation</option>
                    <option value="Regulatory Compliance">Regulatory Compliance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Jurisdiction</label>
                  <select
                    value={jurisdiction}
                    onChange={(e) => setJurisdiction(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="High Court">High Court</option>
                    <option value="Supreme Court">Supreme Court</option>
                    <option value="District Tribunal">District Tribunal</option>
                    <option value="Arbitration Panel">Arbitration Panel</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Parties (Comma separated)</label>
                <input
                  type="text"
                  placeholder="Plaintiff: Apex Corp, Defendant: Zenith Logistics"
                  value={parties}
                  onChange={(e) => setParties(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Description / Notes</label>
                <textarea
                  rows={3}
                  placeholder="Summary of claims, contractual disputes, or legal parameters..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold shadow"
                >
                  {loading ? 'Creating...' : 'Create Case Workspace'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
