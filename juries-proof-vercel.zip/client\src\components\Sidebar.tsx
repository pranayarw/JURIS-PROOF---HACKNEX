import React from 'react';
import { 
  LayoutDashboard, FolderKanban, FileUp, FileText, MessageSquare, 
  FileSearch, Network, GitCompare, AlertTriangle, Calendar, Share2, 
  BookOpen, FileEdit, BarChart2, Printer, HelpCircle 
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const navSections = [
    {
      title: "CORE WORKSPACE",
      items: [
        { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
        { id: "cases", label: "Cases Workspace", icon: FolderKanban },
        { id: "documents", label: "Document Ingestion", icon: FileUp },
        { id: "viewer", label: "Document Viewer", icon: FileText },
      ]
    },
    {
      title: "EVIDENCE INTELLIGENCE",
      items: [
        { id: "chat", label: "Evidence Q&A (RAG)", icon: MessageSquare },
        { id: "review", label: "Case Review", icon: FileSearch },
        { id: "evidence", label: "Evidence Center", icon: Network },
        { id: "contradictions", label: "Contradictions", icon: GitCompare },
        { id: "missing-info", label: "Missing Information", icon: AlertTriangle },
        { id: "timeline", label: "Automatic Timeline", icon: Calendar },
        { id: "relationships", label: "Relationship Map", icon: Share2 },
      ]
    },
    {
      title: "RESEARCH & DRAFTING",
      items: [
        { id: "research", label: "Legal Research", icon: BookOpen },
        { id: "drafting", label: "Legal Drafting", icon: FileEdit },
        { id: "reports", label: "Case Reports", icon: Printer },
      ]
    },
    {
      title: "BENCHMARKS & SYSTEM",
      items: [
        { id: "evaluation", label: "Evaluation Suite", icon: BarChart2 },
        { id: "public-help", label: "Public Legal Help", icon: HelpCircle },
      ]
    }
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 min-h-[calc(100vh-4rem)] border-r border-slate-800 flex flex-col justify-between py-4 shrink-0">
      <div className="space-y-6 px-3">
        {navSections.map((section, idx) => (
          <div key={idx} className="space-y-1">
            <h3 className="px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              {section.title}
            </h3>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 text-xs font-semibold rounded-lg transition ${
                      isActive 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Legal Standard Badge */}
      <div className="px-4 py-3 mx-3 bg-slate-800/80 rounded-lg border border-slate-700/60 text-[11px] text-slate-400 space-y-1">
        <div className="font-semibold text-slate-300 flex items-center space-x-1">
          <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full inline-block"></span>
          <span>PyMuPDF Local Ingestion</span>
        </div>
        <p className="text-[10px] text-slate-500 leading-tight">
          Strict zero-hallucination evidence verification active.
        </p>
      </div>
    </aside>
  );
};
