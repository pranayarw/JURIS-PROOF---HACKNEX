from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Any, Dict
from datetime import datetime

class UserBase(BaseModel):
    email: EmailStr

class UserCreate(UserBase):
    password: str

class UserLogin(UserBase):
    password: str

class UserOut(UserBase):
    id: int
    role: str
    two_factor_enabled: bool
    created_at: datetime

    class Config:
        from_attributes = True

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    two_factor_enabled: Optional[bool] = None

# Assets
class MonitoredAssetBase(BaseModel):
    type: str # email, domain, phone, username, api_key, password_sim, employee_account
    value: str
    label: Optional[str] = None

class MonitoredAssetCreate(MonitoredAssetBase):
    pass

class MonitoredAssetOut(MonitoredAssetBase):
    id: int
    user_id: int
    status: str
    created_at: datetime

    class Config:
        from_attributes = True

# Threats
class ThreatBase(BaseModel):
    leak_source: str
    leak_date: str
    leak_type: str
    risk_score: int
    description: Optional[str] = None
    severity: str
    status: str

class ThreatOut(ThreatBase):
    id: int
    asset_id: int
    ai_analysis: Optional[Dict[str, Any]] = None
    created_at: datetime
    asset: Optional[MonitoredAssetOut] = None

    class Config:
        from_attributes = True

class ThreatUpdate(BaseModel):
    status: Optional[str] = None

# Alerts
class AlertOut(BaseModel):
    id: int
    user_id: int
    threat_id: Optional[int] = None
    type: str
    message: str
    status: str
    sent_at: datetime

    class Config:
        from_attributes = True

class AlertUpdate(BaseModel):
    status: str # read, unread, resolved, dismissed

# Reports
class ReportCreate(BaseModel):
    type: str # executive, threat, monthly

class ReportOut(BaseModel):
    id: int
    user_id: int
    type: str
    file_path: str
    generated_at: datetime

    class Config:
        from_attributes = True

# Tokens
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None
    user_id: Optional[int] = None
    role: Optional[str] = None

# Extension Payload
class ExtensionCheckRequest(BaseModel):
    email_hash: str

class ExtensionCheckResponse(BaseModel):
    is_compromised: bool
    source: Optional[str] = None
    leak_date: Optional[str] = None
    leak_type: Optional[str] = None
    risk_level: Optional[str] = None
    recommendation: Optional[str] = None

class ExtensionSyncRequest(BaseModel):
    domain: str
    https_status: bool
    reputation_score: int
    phishing_score: int
    download_threats: List[str] = []

class ScanRequest(BaseModel):
    domain: str

class ChatRequest(BaseModel):
    message: str
    context: Optional[List[Dict[str, str]]] = None # list of {"role": "user"/"assistant", "content": "..."}
