import React, { useEffect, useState } from 'react';
import { 
  FileUp, CheckCircle, AlertCircle, FileText, Loader2, Eye, Trash2, 
  Layers, Check
} from 'lucide-react';
import { getCaseDocuments, uploadPdfDocument, Case, DocumentItem } from '../services/api';

interface DocumentManagerProps {
  activeCase: Case | null;
  onOpenDocumentViewer: (docId: number) => void;
  onNavigateTab: (tab: string) => void;
}

export const DocumentManagerPage: React.FC<DocumentManagerProps> = ({
  activeCase,
  onOpenDocumentViewer,
  onNavigateTab
}) => {
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [processingStep, setProcessingStep] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (activeCase) {
      fetchDocuments();
    }
  }, [activeCase]);

  const fetchDocuments = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const data = await getCaseDocuments(activeCase.id);
      setDocuments(data);
    } catch (err) {
      console.error('Failed to fetch case documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!activeCase) {
      alert('Please select or create an active case first.');
      return;
    }

    if (!file.name.toLowerCase().endsWith('.pdf')) {
      setErrorMsg('Document processing failed. Please verify that the file is a valid PDF document.');
      return;
    }

    setUploading(true);
    setErrorMsg(null);

    // Simulated step-by-step processing workflow animation
    setProcessingStep('Uploading PDF...');
    await new Promise((r) => setTimeout(r, 400));
    setProcessingStep('Validating file structure...');
    await new Promise((r) => setTimeout(r, 400));
    setProcessingStep('Reading document with PyMuPDF...');
    await new Promise((r) => setTimeout(r, 400));
    setProcessingStep('Extracting page-by-page text...');

    try {
      const res = await uploadPdfDocument(activeCase.id, file);
      setProcessingStep('Indexing chunks & evidence...');
      await new Promise((r) => setTimeout(r, 400));

      setProcessingStep('Document ready!');
      await new Promise((r) => setTimeout(r, 300));

      fetchDocuments();
    } catch (err: any) {
      setErrorMsg(err.response?.data?.detail || 'Document processing failed. Please verify that the PDF is valid and readable.');
    } finally {
      setUploading(false);
      setProcessingStep(null);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <FileUp className="w-5 h-5 text-blue-600" />
            <span>Real PDF Ingestion Pipeline</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            {activeCase 
              ? `Ingesting documents for active case: ${activeCase.case_number} (${activeCase.title})`
              : 'Please select an active case to upload PDFs.'}
          </p>
        </div>

        {/* Supported Formats Badge */}
        <div className="flex items-center space-x-2 text-[11px] font-semibold">
          <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded border border-emerald-300 dark:border-emerald-800">
            PDF — Supported
          </span>
          <span className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded">
            DOCX — Coming soon
          </span>
          <span className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded">
            TXT — Coming soon
          </span>
        </div>
      </div>

      {/* PDF Drag & Drop Upload Card */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 transition text-center space-y-4">
        
        {uploading ? (
          <div className="py-6 space-y-3">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              {processingStep || 'Processing PDF...'}
            </h3>
            <div className="max-w-md mx-auto text-xs text-slate-500 space-y-1 text-left bg-slate-50 dark:bg-slate-800/80 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
              <div className="flex items-center space-x-2">
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Uploading PDF & verifying file integrity</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Page-by-page PyMuPDF text extraction</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Page number preservation & section detection</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Chunk indexing for evidence retrieval</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="py-4 space-y-3">
            <div className="w-12 h-12 bg-blue-50 dark:bg-blue-950/60 rounded-full flex items-center justify-center mx-auto text-blue-600">
              <FileUp className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                Upload Real Case PDF
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Drag & drop your PDF file here, or click to browse files.
              </p>
            </div>

            <label className="inline-flex items-center space-x-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2 rounded-lg cursor-pointer transition shadow-sm">
              <FileUp className="w-4 h-4" />
              <span>Browse PDF File</span>
              <input
                type="file"
                accept=".pdf"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
            </label>

            <span className="text-[11px] text-slate-400 block">
              The uploaded PDF will become the active ground truth evidence source for Q&A and analysis.
            </span>
          </div>
        )}

      </div>

      {/* Error State Banner */}
      {errorMsg && (
        <div className="bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 rounded-xl p-4 flex items-center space-x-3 text-xs text-red-800 dark:text-red-300">
          <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Uploaded Documents Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Uploaded Case Documents</h2>
            <p className="text-xs text-slate-500">Every page text is preserved and indexed with 1-based page numbers.</p>
          </div>
          <span className="text-xs font-bold text-slate-500">{documents.length} File(s)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Document Name</th>
                <th className="px-4 py-3">Pages</th>
                <th className="px-4 py-3">Size</th>
                <th className="px-4 py-3">Uploaded</th>
                <th className="px-4 py-3">Processing Status</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {documents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                    No PDF documents uploaded yet. Upload a PDF above to begin evidence analysis.
                  </td>
                </tr>
              ) : (
                documents.map((doc) => (
                  <tr key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white flex items-center space-x-2">
                      <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                      <span className="truncate max-w-[220px]">{doc.document_name}</span>
                    </td>
                    <td className="px-4 py-3 text-slate-700 dark:text-slate-300 font-mono font-bold">
                      {doc.page_count} page(s)
                    </td>
                    <td className="px-4 py-3 text-slate-500">
                      {(doc.file_size / 1024).toFixed(1)} KB
                    </td>
                    <td className="px-4 py-3 text-slate-500">
                      {doc.upload_date ? new Date(doc.upload_date).toLocaleDateString() : 'Just now'}
                    </td>
                    <td className="px-4 py-3">
                      {doc.is_scanned ? (
                        <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 rounded font-bold text-[10px]">
                          Scanned PDF (OCR Required)
                        </span>
                      ) : doc.processing_status === 'ready' ? (
                        <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded font-bold text-[10px] flex items-center space-x-1 w-max">
                          <CheckCircle className="w-3 h-3" />
                          <span>Ready</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 rounded font-bold text-[10px] flex items-center space-x-1 w-max">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          <span>{doc.processing_status}</span>
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => onOpenDocumentViewer(doc.id)}
                        className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold transition inline-flex items-center space-x-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Open Viewer</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
