import React, { useEffect, useState } from 'react';
import { GitCompare, ShieldAlert, FileText, CheckCircle2 } from 'lucide-react';
import { getContradictions, Case } from '../services/api';

interface ContradictionViewProps {
  activeCase: Case | null;
}

export const ContradictionViewPage: React.FC<ContradictionViewProps> = ({ activeCase }) => {
  const [contradictions, setContradictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeCase) {
      fetchContradictions();
    }
  }, [activeCase]);

  const fetchContradictions = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const data = await getContradictions(activeCase.id);
      setContradictions(data);
    } catch (err) {
      console.error('Failed to fetch contradictions:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to inspect document contradictions.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <GitCompare className="w-5 h-5 text-red-600" />
            <span>Cross-Document Contradiction Engine</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Detects conflicting factual entries, payment dates, or obligations across uploaded PDF exhibits.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-400">
          Cross-examining document pages for conflicting claims...
        </div>
      ) : contradictions.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Zero Contradictions Detected</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            All extracted dates, monetary amounts, and claims across uploaded PDFs are consistent.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {contradictions.map((c) => (
            <div
              key={c.id}
              className="bg-white dark:bg-slate-900 rounded-xl p-6 border-2 border-red-200 dark:border-red-900/60 shadow-sm space-y-4"
            >
              {/* Contradiction Title Header */}
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex items-center space-x-2 text-red-600 dark:text-red-400 font-bold text-sm">
                  <ShieldAlert className="w-5 h-5" />
                  <span>CONTRADICTION DETECTED: {c.title}</span>
                </div>
                <span className="px-2.5 py-0.5 bg-red-100 dark:bg-red-950 text-red-800 dark:text-red-300 rounded font-extrabold text-[10px]">
                  {c.status}
                </span>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                {c.description}
              </p>

              {/* Side by Side Comparison Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Claim A */}
                <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-blue-600 dark:text-blue-400">Claim Exhibit A</span>
                    <span className="text-slate-500 font-mono">Page {c.page_a}</span>
                  </div>
                  <p className="text-xs text-slate-800 dark:text-slate-200 font-serif italic">
                    "{c.claim_a}"
                  </p>
                  <span className="text-[10px] text-slate-400 block pt-1 border-t border-slate-200 dark:border-slate-700">
                    Source: Document #{c.doc_a_id} — Page {c.page_a}
                  </span>
                </div>

                {/* Claim B */}
                <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-red-600 dark:text-red-400">Claim Exhibit B</span>
                    <span className="text-slate-500 font-mono">Page {c.page_b}</span>
                  </div>
                  <p className="text-xs text-slate-800 dark:text-slate-200 font-serif italic">
                    "{c.claim_b}"
                  </p>
                  <span className="text-[10px] text-slate-400 block pt-1 border-t border-slate-200 dark:border-slate-700">
                    Source: Document #{c.doc_b_id} — Page {c.page_b}
                  </span>
                </div>

              </div>

              <div className="text-[11px] text-slate-500 italic bg-amber-50 dark:bg-amber-950/40 p-2.5 rounded border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
                Note: JURIES PROOF does not arbitrarily decide which exhibit is correct. Both sources are presented to the legal analyst for review.
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};
