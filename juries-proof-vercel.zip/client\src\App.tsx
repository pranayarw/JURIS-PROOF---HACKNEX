import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardPage } from './pages/Dashboard';
import { CaseManagementPage } from './pages/CaseManagement';
import { DocumentManagerPage } from './pages/DocumentManager';
import { DocumentViewerPage } from './pages/DocumentViewer';
import { EvidenceChatPage } from './pages/EvidenceChat';
import { CaseReviewPage } from './pages/CaseReview';
import { EvidenceCenterPage } from './pages/EvidenceCenter';
import { ContradictionViewPage } from './pages/ContradictionView';
import { MissingInfoViewPage } from './pages/MissingInfoView';
import { TimelineViewPage } from './pages/TimelineView';
import { RelationshipMapPage } from './pages/RelationshipMap';
import { LegalResearchPage } from './pages/LegalResearch';
import { LegalDraftingPage } from './pages/LegalDrafting';
import { EvaluationViewPage } from './pages/EvaluationView';
import { PublicHelpViewPage } from './pages/PublicHelpView';
import { ReportsViewPage } from './pages/ReportsView';
import { getCases, createCase, Case } from './services/api';

export function App() {
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [cases, setCases] = useState<Case[]>([]);
  const [activeCase, setActiveCase] = useState<Case | null>(null);
  const [selectedDocumentId, setSelectedDocumentId] = useState<number | null>(null);
  const [userRole, setUserRole] = useState<string>('Analyst');
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);

  // Modal form states
  const [modalTitle, setModalTitle] = useState('');
  const [modalType, setModalType] = useState('Commercial / Contract');
  const [modalJurisdiction, setModalJurisdiction] = useState('High Court');
  const [modalDesc, setModalDesc] = useState('');
  const [modalParties, setModalParties] = useState('');
  const [modalLoading, setModalLoading] = useState(false);

  useEffect(() => {
    loadCases();
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const loadCases = async () => {
    try {
      const data = await getCases();
      setCases(data);
      if (data.length > 0 && !activeCase) {
        setActiveCase(data[0]);
      }
    } catch (err) {
      console.error('Failed to load initial cases:', err);
    }
  };

  const handleOpenDocumentViewer = (docId: number) => {
    setSelectedDocumentId(docId);
    setActiveTab('viewer');
  };

  const handleCreateCaseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalTitle.trim()) return;

    setModalLoading(true);
    try {
      const formData = new FormData();
      formData.append('title', modalTitle);
      formData.append('case_type', modalType);
      formData.append('jurisdiction', modalJurisdiction);
      formData.append('description', modalDesc);
      formData.append('parties', modalParties);

      const newCase = await createCase(formData);
      setCases([newCase, ...cases]);
      setActiveCase(newCase);
      setShowCreateModal(false);

      // Reset
      setModalTitle('');
      setModalDesc('');
      setModalParties('');
    } catch (err) {
      alert('Failed to create new case');
    } finally {
      setModalLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 font-sans flex flex-col">
      
      {/* Top Header Navbar */}
      <Navbar
        cases={cases}
        activeCase={activeCase}
        onSelectCase={(c) => setActiveCase(c)}
        onOpenCreateCaseModal={() => setShowCreateModal(true)}
        userRole={userRole}
        onRoleChange={(role) => setUserRole(role)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />

      <div className="flex flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-6">
        
        {/* Navigation Sidebar */}
        <Sidebar activeTab={activeTab} onSelectTab={(tab) => setActiveTab(tab)} />

        {/* Main Content Area */}
        <main className="flex-1 min-w-0">
          {activeTab === 'dashboard' && (
            <DashboardPage
              activeCase={activeCase}
              onSelectCase={(c) => setActiveCase(c)}
              onNavigateTab={(t) => setActiveTab(t)}
            />
          )}

          {activeTab === 'cases' && (
            <CaseManagementPage
              activeCase={activeCase}
              onSelectCase={(c) => setActiveCase(c)}
              onNavigateTab={(t) => setActiveTab(t)}
            />
          )}

          {activeTab === 'documents' && (
            <DocumentManagerPage
              activeCase={activeCase}
              onOpenDocumentViewer={handleOpenDocumentViewer}
              onNavigateTab={(t) => setActiveTab(t)}
            />
          )}

          {activeTab === 'viewer' && (
            <DocumentViewerPage
              documentId={selectedDocumentId}
              onBack={() => setActiveTab('documents')}
            />
          )}

          {activeTab === 'chat' && (
            <EvidenceChatPage
              activeCase={activeCase}
              onOpenDocumentViewer={handleOpenDocumentViewer}
            />
          )}

          {activeTab === 'review' && (
            <CaseReviewPage activeCase={activeCase} />
          )}

          {activeTab === 'evidence' && (
            <EvidenceCenterPage activeCase={activeCase} />
          )}

          {activeTab === 'contradictions' && (
            <ContradictionViewPage activeCase={activeCase} />
          )}

          {activeTab === 'missing-info' && (
            <MissingInfoViewPage activeCase={activeCase} />
          )}

          {activeTab === 'timeline' && (
            <TimelineViewPage activeCase={activeCase} />
          )}

          {activeTab === 'relationships' && (
            <RelationshipMapPage activeCase={activeCase} />
          )}

          {activeTab === 'research' && (
            <LegalResearchPage activeCase={activeCase} />
          )}

          {activeTab === 'drafting' && (
            <LegalDraftingPage activeCase={activeCase} />
          )}

          {activeTab === 'evaluation' && (
            <EvaluationViewPage />
          )}

          {activeTab === 'reports' && (
            <ReportsViewPage activeCase={activeCase} />
          )}

          {activeTab === 'public-help' && (
            <PublicHelpViewPage />
          )}
        </main>

      </div>

      {/* Footer Legal Disclaimer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-4 px-4 text-center text-[11px] text-slate-500">
        <div className="max-w-7xl mx-auto">
          JURIES PROOF is a prototype for legal document analysis, research assistance, and evidence organization. It does not provide legal advice, does not replace a qualified legal professional, and should not be relied upon as a substitute for professional legal judgment or official legal authorities.
        </div>
      </footer>

      {/* Global Quick Create Case Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Create New Case Workspace
            </h2>

            <form onSubmit={handleCreateCaseSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Case Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. State vs. Zenith Energy Corp"
                  value={modalTitle}
                  onChange={(e) => setModalTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Case Type</label>
                  <select
                    value={modalType}
                    onChange={(e) => setModalType(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="Commercial / Contract">Commercial / Contract</option>
                    <option value="Criminal Defense">Criminal Defense</option>
                    <option value="Intellectual Property">Intellectual Property</option>
                    <option value="Civil Litigation">Civil Litigation</option>
                    <option value="Regulatory Compliance">Regulatory Compliance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Jurisdiction</label>
                  <select
                    value={modalJurisdiction}
                    onChange={(e) => setModalJurisdiction(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="High Court">High Court</option>
                    <option value="Supreme Court">Supreme Court</option>
                    <option value="District Tribunal">District Tribunal</option>
                    <option value="Arbitration Panel">Arbitration Panel</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Parties (Comma separated)</label>
                <input
                  type="text"
                  placeholder="Plaintiff: State, Defendant: Zenith Energy"
                  value={modalParties}
                  onChange={(e) => setModalParties(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Case notes or legal context..."
                  value={modalDesc}
                  onChange={(e) => setModalDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold shadow"
                >
                  {modalLoading ? 'Creating...' : 'Create Case Workspace'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
