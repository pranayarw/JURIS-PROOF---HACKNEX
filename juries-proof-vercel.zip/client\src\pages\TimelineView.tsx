import React, { useEffect, useState } from 'react';
import { Calendar, FileText, CheckCircle2, User } from 'lucide-react';
import { getTimeline, Case } from '../services/api';

interface TimelineViewProps {
  activeCase: Case | null;
}

export const TimelineViewPage: React.FC<TimelineViewProps> = ({ activeCase }) => {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeCase) {
      fetchTimeline();
    }
  }, [activeCase]);

  const fetchTimeline = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const data = await getTimeline(activeCase.id);
      setEvents(data);
    } catch (err) {
      console.error('Failed to fetch timeline:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to view the Automatic Timeline.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            <span>Automatic Source-Backed Case Timeline</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Chronological events automatically extracted from uploaded PDF pages. Every event links to a verified document page.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-400">
          Extracting dates and compiling chronological event timeline...
        </div>
      ) : events.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <Calendar className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">No Timeline Events Extracted Yet</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Upload PDF documents containing date entries to construct an automated timeline.
          </p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="relative border-l-2 border-blue-500 ml-4 space-y-8 py-2">
            {events.map((evt, idx) => (
              <div key={idx} className="relative pl-6">
                
                {/* Timeline Node Icon */}
                <div className="absolute -left-[17px] top-0.5 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center border-4 border-white dark:border-slate-900 shadow">
                  <Calendar className="w-3.5 h-3.5" />
                </div>

                {/* Event Card */}
                <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-blue-600 dark:text-blue-400 text-xs">
                      {evt.date}
                    </span>
                    <span className="text-[10px] bg-white dark:bg-slate-900 px-2 py-0.5 rounded font-semibold text-slate-500 border border-slate-200 dark:border-slate-700 flex items-center space-x-1">
                      <FileText className="w-3 h-3 text-blue-500" />
                      <span>{evt.document_name} — Page {evt.page_number}</span>
                    </span>
                  </div>

                  <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                    {evt.title}
                  </h3>

                  <p className="text-xs text-slate-700 dark:text-slate-300 font-serif italic">
                    {evt.description}
                  </p>

                  {evt.parties && evt.parties.length > 0 && (
                    <div className="flex items-center space-x-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-[10px] text-slate-500">
                      <User className="w-3 h-3 text-slate-400" />
                      <span>Parties: {evt.parties.join(', ')}</span>
                    </div>
                  )}
                </div>

              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
