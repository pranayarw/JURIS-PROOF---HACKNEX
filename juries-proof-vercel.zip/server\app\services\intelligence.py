import re
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from ..models import (
    Case, Document, DocumentChunk, Claim, Evidence, Citation, 
    Contradiction, MissingInformation, CaseEvent, LegalSource
)

def analyze_case_contradictions(case_id: int, db: Session) -> List[Dict[str, Any]]:
    """
    Detects contradicting claims/dates/amounts across documents within the same case.
    e.g. Document A specifies payment date as 10 March while Document B states 14 March.
    """
    docs = db.query(Document).filter(Document.case_id == case_id).all()
    if len(docs) < 2:
        # Cross-document contradiction requires at least 2 uploaded documents or multiple sections
        return db.query(Contradiction).filter(Contradiction.case_id == case_id).all()

    chunks = db.query(DocumentChunk).filter(DocumentChunk.case_id == case_id).all()
    
    # Simple entity extraction for dates and amounts
    date_regex = re.compile(r'\b(?:\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}|\b\d{4}-\d{2}-\d{2})\b', re.IGNORECASE)
    amount_regex = re.compile(r'(?:₹|\$|USD|INR|EUR)\s*[\d,]+(?:\.\d{2})?', re.IGNORECASE)

    extracted_facts = []
    for c in chunks:
        doc = db.query(Document).filter(Document.id == c.document_id).first()
        doc_name = doc.document_name if doc else f"Doc #{c.document_id}"

        dates = date_regex.findall(c.text)
        amounts = amount_regex.findall(c.text)

        for d in dates:
            extracted_facts.append({
                "type": "date",
                "val": d,
                "doc_id": c.document_id,
                "doc_name": doc_name,
                "page": c.page_number,
                "text": c.text[:150]
            })
        for a in amounts:
            extracted_facts.append({
                "type": "amount",
                "val": a,
                "doc_id": c.document_id,
                "doc_name": doc_name,
                "page": c.page_number,
                "text": c.text[:150]
            })

    # Compare facts across different documents
    for i in range(len(extracted_facts)):
        for j in range(i+1, len(extracted_facts)):
            fact1 = extracted_facts[i]
            fact2 = extracted_facts[j]

            # Different doc, same fact type, different value in related context
            if fact1["doc_id"] != fact2["doc_id"] and fact1["type"] == fact2["type"] and fact1["val"] != fact2["val"]:
                # Check if contradiction entry already exists
                existing = db.query(Contradiction).filter(
                    Contradiction.case_id == case_id,
                    Contradiction.doc_a_id == fact1["doc_id"],
                    Contradiction.doc_b_id == fact2["doc_id"],
                    Contradiction.page_a == fact1["page"],
                    Contradiction.page_b == fact2["page"]
                ).first()

                if not existing:
                    contradiction = Contradiction(
                        case_id=case_id,
                        title=f"Conflicting {fact1['type'].capitalize()} Entry",
                        description=f"Mismatch found between {fact1['doc_name']} ({fact1['val']}) and {fact2['doc_name']} ({fact2['val']}).",
                        claim_a=f"{fact1['type'].capitalize()}: {fact1['val']} (Source: {fact1['text']}...)",
                        claim_b=f"{fact1['type'].capitalize()}: {fact2['val']} (Source: {fact2['text']}...)",
                        doc_a_id=fact1["doc_id"],
                        page_a=fact1["page"],
                        doc_b_id=fact2["doc_id"],
                        page_b=fact2["page"],
                        status="CRITICAL"
                    )
                    db.add(contradiction)

    db.commit()
    return db.query(Contradiction).filter(Contradiction.case_id == case_id).all()


def calculate_evidence_coverage(case_id: int, db: Session) -> Dict[str, Any]:
    claims = db.query(Claim).filter(Claim.case_id == case_id).all()
    total_claims = len(claims)
    
    if total_claims == 0:
        return {
            "total_claims": 0,
            "verified_claims": 0,
            "partially_supported": 0,
            "unsupported": 0,
            "contradicted": 0,
            "insufficient_evidence": 0,
            "coverage_percentage": 0.0,
            "status": "Not enough evaluated claims to calculate evidence coverage."
        }

    verified = sum(1 for c in claims if c.verification_status == "VERIFIED")
    partial = sum(1 for c in claims if c.verification_status == "PARTIALLY SUPPORTED")
    unsupported = sum(1 for c in claims if c.verification_status == "UNSUPPORTED")
    contradicted = sum(1 for c in claims if c.verification_status == "CONTRADICTED")
    insufficient = sum(1 for c in claims if c.verification_status == "INSUFFICIENT EVIDENCE")

    coverage = (verified / total_claims) * 100.0

    return {
        "total_claims": total_claims,
        "verified_claims": verified,
        "partially_supported": partial,
        "unsupported": unsupported,
        "contradicted": contradicted,
        "insufficient_evidence": insufficient,
        "coverage_percentage": round(coverage, 1),
        "status": f"{round(coverage, 1)}% of claims strictly verified against uploaded PDF evidence."
    }


def generate_evidence_graph_data(case_id: int, db: Session) -> Dict[str, Any]:
    case_obj = db.query(Case).filter(Case.id == case_id).first()
    docs = db.query(Document).filter(Document.case_id == case_id).all()
    claims = db.query(Claim).filter(Claim.case_id == case_id).all()
    events = db.query(CaseEvent).filter(CaseEvent.case_id == case_id).all()

    nodes = []
    links = []

    # Case root node
    case_title = case_obj.title if case_obj else f"Case #{case_id}"
    nodes.append({
        "id": f"case-{case_id}",
        "label": case_title,
        "type": "Case",
        "category": "root"
    })

    # Document nodes
    for doc in docs:
        doc_node_id = f"doc-{doc.id}"
        nodes.append({
            "id": doc_node_id,
            "label": doc.document_name,
            "type": "Document",
            "category": "document",
            "page_count": doc.page_count
        })
        links.append({
            "source": f"case-{case_id}",
            "target": doc_node_id,
            "label": "contains_document"
        })

    # Claim nodes
    for claim in claims:
        claim_node_id = f"claim-{claim.id}"
        nodes.append({
            "id": claim_node_id,
            "label": claim.text[:40] + "...",
            "type": "Claim",
            "category": "claim",
            "status": claim.verification_status
        })
        # Link claim to document if doc exists
        if claim.document_id:
            links.append({
                "source": f"doc-{claim.document_id}",
                "target": claim_node_id,
                "label": f"extracted_from_p{claim.page_number}"
            })
        else:
            links.append({
                "source": f"case-{case_id}",
                "target": claim_node_id,
                "label": "asserts_claim"
            })

    # Event nodes
    for evt in events:
        evt_node_id = f"event-{evt.id}"
        nodes.append({
            "id": evt_node_id,
            "label": f"{evt.date_str}: {evt.title}",
            "type": "Event",
            "category": "event"
        })
        if evt.document_id:
            links.append({
                "source": f"doc-{evt.document_id}",
                "target": evt_node_id,
                "label": f"event_on_p{evt.page_number}"
            })

    return {
        "nodes": nodes,
        "links": links
    }
