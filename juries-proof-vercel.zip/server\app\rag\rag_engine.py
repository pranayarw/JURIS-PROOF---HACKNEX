import os
import re
import math
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from ..models import DocumentChunk, Document, Claim, Evidence, Citation, MissingInformation

def tokenize(text: str) -> List[str]:
    return [w.lower() for w in re.findall(r'\b\w+\b', text) if len(w) > 2]

def calculate_bm25_score(query_tokens: List[str], doc_tokens: List[str], avg_dl: float, k1=1.5, b=0.75) -> float:
    score = 0.0
    doc_len = len(doc_tokens)
    if doc_len == 0:
        return 0.0
    
    # Calculate term frequency
    tf_map = {}
    for t in doc_tokens:
        tf_map[t] = tf_map.get(t, 0) + 1
        
    for q in query_tokens:
        if q in tf_map:
            freq = tf_map[q]
            # IDF approximation
            idf = math.log((100 + 1) / (1 + 0.5)) + 1
            num = freq * (k1 + 1)
            denom = freq + k1 * (1 - b + b * (doc_len / (avg_dl or 1.0)))
            score += idf * (num / denom)
    return score

def query_case_evidence(case_id: int, query: str, db: Session, top_k: int = 5) -> Dict[str, Any]:
    """
    Evidence-First Grounded RAG Query Engine:
    1. Filter document chunks strictly by case_id
    2. BM25 / TF-IDF similarity search over extracted PDF text
    3. Strict relevance threshold evaluation
    4. IF insufficient match -> Refuses with INSUFFICIENT EVIDENCE (Zero Hallucination)
    5. IF sufficient match -> Returns grounded answer with exact page citations and Why? explanation
    """
    chunks = db.query(DocumentChunk).filter(DocumentChunk.case_id == case_id).all()
    
    if not chunks:
        # Case has no documents uploaded yet
        return {
            "status": "INSUFFICIENT EVIDENCE",
            "verification_status": "INSUFFICIENT EVIDENCE",
            "answer": "INSUFFICIENT EVIDENCE\n\nNo document evidence has been uploaded to this case yet. Please upload a PDF document to begin analysis.",
            "citations": [],
            "supporting_evidence": [],
            "missing_info": [
                {
                    "item": "Primary Case Document / PDF",
                    "reason": "No PDF documents available in the current case workspace.",
                    "recommended_action": "Upload a valid PDF document under Document Management."
                }
            ],
            "why_explanation": {
                "claim": query,
                "source": "None",
                "page": None,
                "section": None,
                "status": "INSUFFICIENT EVIDENCE",
                "reasoning": "Zero documents found in active case workspace."
            }
        }

    query_tokens = tokenize(query)
    if not query_tokens:
        query_tokens = [w.lower() for w in query.split() if w]

    # Calculate average doc length
    chunk_tokens_list = [tokenize(c.text) for c in chunks]
    avg_dl = sum(len(t) for t in chunk_tokens_list) / max(len(chunks), 1)

    scored_chunks = []
    for chunk, tokens in zip(chunks, chunk_tokens_list):
        score = calculate_bm25_score(query_tokens, tokens, avg_dl)
        if score > 0:
            scored_chunks.append((score, chunk))

    scored_chunks.sort(key=lambda x: x[0], reverse=True)
    top_matches = scored_chunks[:top_k]

    # RELEVANCE SCORE THRESHOLD FOR REFUSAL
    # If top match score is very low or 0 -> Refuse with INSUFFICIENT EVIDENCE
    if not top_matches or top_matches[0][0] < 0.25:
        # Identify nearest partial chunk if any for missing info context
        nearest_context = chunks[0].text[:200] if chunks else "No relevant context."
        
        # Log missing info requirement in DB
        missing_item = MissingInformation(
            case_id=case_id,
            item_name=f"Evidence regarding '{query[:50]}'",
            why_required=f"User asked: '{query}', but available document text does not contain relevant clauses.",
            priority="HIGH",
            recommended_action="Upload additional case documents, contract addendums, or bank statements containing this specific detail.",
            status="OPEN"
        )
        db.add(missing_item)
        db.commit()

        return {
            "status": "INSUFFICIENT EVIDENCE",
            "verification_status": "INSUFFICIENT EVIDENCE",
            "answer": f"INSUFFICIENT EVIDENCE\n\nThe available documents in this case do not provide sufficient evidence to answer: \"{query}\".\n\nThe system refuses to speculate or generate answers when supporting source proof is unavailable.",
            "citations": [],
            "supporting_evidence": [],
            "missing_info": [
                {
                    "item": f"Document evidence for: {query[:60]}",
                    "reason": "The uploaded PDF pages do not contain matching text, contract clauses, or factual entries for this question.",
                    "recommended_action": "Verify if the fact is present in a separate annexure or upload an updated case PDF."
                }
            ],
            "why_explanation": {
                "claim": query,
                "source": "Searched all active case pages",
                "page": None,
                "section": None,
                "status": "INSUFFICIENT EVIDENCE",
                "reasoning": "Search score fell below mandatory confidence threshold (0.25). System invoked Insufficient Evidence protocol."
            }
        }

    # Gather top supporting evidence chunks
    supporting_evidence = []
    citations = []

    for score, chunk in top_matches:
        doc = db.query(Document).filter(Document.id == chunk.document_id).first()
        doc_name = doc.document_name if doc else f"Doc #{chunk.document_id}"

        evidence_entry = {
            "chunk_id": chunk.id,
            "document_id": chunk.document_id,
            "document_name": doc_name,
            "page_number": chunk.page_number,
            "section": chunk.section or f"Page {chunk.page_number}",
            "text": chunk.text,
            "score": round(score, 3)
        }
        supporting_evidence.append(evidence_entry)

        citation_entry = {
            "document_name": doc_name,
            "page_number": chunk.page_number,
            "section": chunk.section or f"Page {chunk.page_number}",
            "status": "VERIFIED",
            "excerpt": chunk.text[:150] + "..."
        }
        if citation_entry not in citations:
            citations.append(citation_entry)

    # Check for Gemini / OpenAI API key for enhanced natural language synthesis
    gemini_key = os.getenv("GEMINI_API_KEY")
    openai_key = os.getenv("OPENAI_API_KEY")

    best_match = top_matches[0][1]
    best_doc = db.query(Document).filter(Document.id == best_match.document_id).first()
    best_doc_name = best_doc.document_name if best_doc else f"Doc #{best_match.document_id}"

    if gemini_key or openai_key:
        try:
            # Enhanced AI synthesis using local chunks as strict ground truth
            # We enforce strict grounding prompt
            answer_text = generate_ai_grounded_answer(query, supporting_evidence)
            verification_status = "VERIFIED"
        except Exception:
            answer_text = build_deterministic_grounded_answer(query, supporting_evidence)
            verification_status = "VERIFIED"
    else:
        answer_text = build_deterministic_grounded_answer(query, supporting_evidence)
        verification_status = "VERIFIED"

    why_explanation = {
        "claim": f"Grounded Answer for: '{query}'",
        "source": best_doc_name,
        "page": best_match.page_number,
        "section": best_match.section or f"Page {best_match.page_number}",
        "evidence_excerpt": best_match.text,
        "status": "VERIFIED",
        "reasoning": f"Evidence score {round(top_matches[0][0], 3)} confirms exact text match on Page {best_match.page_number} of {best_doc_name}."
    }

    return {
        "status": "SUCCESS",
        "verification_status": verification_status,
        "answer": answer_text,
        "citations": citations,
        "supporting_evidence": supporting_evidence,
        "missing_info": [],
        "why_explanation": why_explanation
    }


def build_deterministic_grounded_answer(query: str, supporting_evidence: List[Dict[str, Any]]) -> str:
    top_chunk = supporting_evidence[0]
    doc_name = top_chunk["document_name"]
    page_num = top_chunk["page_number"]
    section = top_chunk["section"]
    text_snippet = top_chunk["text"]

    return (
        f"Based on direct evidence extracted from **{doc_name}** (Page {page_num}, Section: {section}):\n\n"
        f"\"{text_snippet}\"\n\n"
        f"**VERIFIED SOURCE**: {doc_name} — Page {page_num}."
    )


def generate_ai_grounded_answer(query: str, supporting_evidence: List[Dict[str, Any]]) -> str:
    # Uses requests to call Gemini REST API if GEMINI_API_KEY is configured
    gemini_key = os.getenv("GEMINI_API_KEY")
    if gemini_key:
        import requests
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
        
        context_str = "\n\n".join([
            f"[Source: {ev['document_name']}, Page {ev['page_number']}, Section: {ev['section']}]\n{ev['text']}"
            for ev in supporting_evidence
        ])

        prompt = (
            f"You are JURIES PROOF legal intelligence engine.\n"
            f"STRICT RULE: Answer the user question using ONLY the provided document evidence.\n"
            f"If the provided evidence does not contain the answer, reply with 'INSUFFICIENT EVIDENCE'.\n\n"
            f"EVIDENCE:\n{context_str}\n\n"
            f"QUESTION: {query}\n\n"
            f"Provide a clear, grounded legal summary with source citations."
        )

        headers = {"Content-Type": "application/json"}
        payload = {
            "contents": [{"parts": [{"text": prompt}]}]
        }
        res = requests.post(url, json=payload, headers=headers, timeout=10)
        if res.status_code == 200:
            data = res.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
            
    return build_deterministic_grounded_answer(query, supporting_evidence)
