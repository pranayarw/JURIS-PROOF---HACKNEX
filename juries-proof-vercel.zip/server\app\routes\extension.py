import hashlib
import json
import os
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Dict, Any, Optional
from datetime import datetime
from ..database import get_db
from .. import models, schemas, auth_utils

router = APIRouter(prefix="/extension", tags=["Browser Extension API"])

# Cache for loaded mock breaches
MOCK_BREACH_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "shared", "mock_breaches.json")

def load_mock_breaches() -> List[Dict[str, Any]]:
    try:
        with open(MOCK_BREACH_PATH, "r") as f:
            return json.load(f)
    except Exception:
        return []

def get_hash(text: str, algo: str = "sha256") -> str:
    text_bytes = text.lower().strip().encode("utf-8")
    if algo == "md5":
        return hashlib.md5(text_bytes).hexdigest()
    return hashlib.sha256(text_bytes).hexdigest()

@router.get("/check")
def check_email_compromise(
    q: str = Query(..., description="Plain email or md5/sha256 hash of email"),
    db: Session = Depends(get_db)
):
    """
    Checks if a local email or locally-hashed email appears in any known breach.
    Does not store search value on breach hit, protecting user security.
    """
    breaches = load_mock_breaches()
    search_term = q.lower().strip()
    
    for breach in breaches:
        for affected in breach["affected_assets"]:
            if affected["type"] != "email":
                continue
                
            email_val = affected["value"].lower().strip()
            # Generate hashes for checking
            email_md5 = get_hash(email_val, "md5")
            email_sha256 = get_hash(email_val, "sha256")
            
            # Match plain email, MD5 hash, or SHA256 hash
            if search_term in (email_val, email_md5, email_sha256):
                # Return compromise detail
                # Map breach risk (High, Medium, Low, Critical) to details
                risk = breach.get("risk", "High")
                rec = "We recommend resetting passwords on this service and any other site reusing this password."
                
                return {
                    "is_compromised": True,
                    "source": breach["source"],
                    "leak_date": breach["date"],
                    "leak_type": breach["leak_type"],
                    "risk_level": risk,
                    "recommendation": rec
                }
                
    return {
        "is_compromised": False,
        "source": None,
        "leak_date": None,
        "leak_type": None,
        "risk_level": "None",
        "recommendation": "Email is secure. No matches found in simulated breach database."
    }

@router.get("/domain")
def check_domain_safety(
    domain: str = Query(..., description="Target domain to analyze, e.g. target.com")
):
    """
    Analyzes domain safety rating, certificate validity, reputation, and phishing indicators.
    """
    dom = domain.lower().strip()
    
    # Heuristics
    trust_score = 92
    phishing_score = 5
    is_suspicious = False
    reasons = []
    
    # Flags for mock phishing detection
    phishing_triggers = ["phish", "secure-login", "signin-verification", "free-gift", "update-credentials", "update-bank"]
    typosquat_triggers = ["g00gle", "faceb00k", "micro-soft", "paypal-auth", "netflix-login"]
    
    if any(trigger in dom for trigger in phishing_triggers):
        trust_score = 15
        phishing_score = 88
        is_suspicious = True
        reasons.append("Contains suspicious credential-harvesting keywords")
        
    if any(trigger in dom for trigger in typosquat_triggers):
        trust_score = 22
        phishing_score = 75
        is_suspicious = True
        reasons.append("Matches brand-impersonation (typosquatting) signature")
        
    if dom.startswith("http://"):
        trust_score = max(5, trust_score - 40)
        reasons.append("Unencrypted connection (HTTP)")
        
    if len(dom) < 8: # Short or suspicious domain structures
        pass
        
    return {
        "domain": domain,
        "trust_score": trust_score,
        "ssl_status": "Valid certificate (TLS 1.3)" if not dom.startswith("http://") else "No SSL / Insecure",
        "domain_age": "4 Years, 2 Months" if trust_score > 60 else "2 Days",
        "phishing_probability": phishing_score,
        "blacklist_status": "Listed" if is_suspicious else "Clean",
        "reasons": reasons if reasons else ["Domain shows normal administrative profiles"],
        "risk_indicator": "green" if trust_score >= 80 else ("yellow" if trust_score >= 50 else "red")
    }

@router.post("/sync")
def sync_extension_data(
    payload: Dict[str, Any],
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db)
):
    """
    Syncs user extension navigation telemetry and local warning hits back to database.
    """
    domain = payload.get("domain", "Unknown")
    alerts = payload.get("alerts", [])
    
    # Write a log entry
    action_log = f"Extension Telemetry Sync: User visited '{domain}'."
    if alerts:
        action_log += f" Threat warnings generated: {', '.join(alerts)}"
        
    new_log = models.SystemLog(
        action=action_log,
        ip_address=payload.get("ip_address"),
        user_agent=payload.get("user_agent")
    )
    db.add(new_log)
    
    # If there are security threat alerts from the extension, we can create Dashboard Alerts!
    for alert_msg in alerts:
        new_alert = models.Alert(
            user_id=current_user.id,
            threat_id=None,
            type="push",
            message=f"Browser Extension alert on '{domain}': {alert_msg}",
            status="unread"
        )
        db.add(new_alert)
        
    db.commit()
    return {"status": "success", "synced_at": datetime.utcnow()}
