import React, { useEffect, useState } from 'react';
import { 
  Briefcase, FileText, CheckCircle2, ShieldAlert, AlertTriangle, 
  HelpCircle, BookOpen, FileEdit, ArrowRight, Upload, Plus 
} from 'lucide-react';
import { getDashboardMetrics, getCases, Case, DashboardMetrics } from '../services/api';

interface DashboardProps {
  activeCase: Case | null;
  onSelectCase: (c: Case) => void;
  onNavigateTab: (tab: string) => void;
}

export const DashboardPage: React.FC<DashboardProps> = ({
  activeCase,
  onSelectCase,
  onNavigateTab
}) => {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [recentCases, setRecentCases] = useState<Case[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, [activeCase]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const m = await getDashboardMetrics(activeCase?.id);
      setMetrics(m);
      const cList = await getCases();
      setRecentCases(cList);
    } catch (err) {
      console.error('Failed to load dashboard metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 rounded-xl p-6 text-white border border-slate-700 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 bg-blue-600/30 text-blue-300 text-[10px] font-extrabold uppercase tracking-wider rounded border border-blue-500/40">
              PROTOTYPE • REAL DOCUMENT ANALYSIS
            </span>
          </div>
          <h1 className="text-2xl font-bold mt-2">Legal Intelligence Dashboard</h1>
          <p className="text-slate-300 text-sm mt-1 max-w-2xl">
            {activeCase 
              ? `Currently analyzing active workspace: ${activeCase.case_number} — ${activeCase.title}` 
              : 'Real PDF ingestion, page-indexed evidence retrieval, and zero-hallucination claim verification.'}
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={() => onNavigateTab('documents')}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow transition"
          >
            <Upload className="w-4 h-4" />
            <span>Upload PDF</span>
          </button>
          <button
            onClick={() => onNavigateTab('cases')}
            className="flex items-center space-x-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold px-4 py-2.5 rounded-lg border border-slate-600 transition"
          >
            <Plus className="w-4 h-4" />
            <span>New Case</span>
          </button>
        </div>
      </div>

      {/* Primary Intelligence Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        {/* Metric 1: Active Cases */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider">Active Cases</span>
            <Briefcase className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {metrics?.active_cases ?? 0}
            </span>
            <span className="text-xs text-slate-500 block mt-0.5">Isolated Workspaces</span>
          </div>
        </div>

        {/* Metric 2: Documents Processed */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider">PDFs Processed</span>
            <FileText className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {metrics?.documents_processed ?? 0}
            </span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 block mt-0.5 font-medium">
              PyMuPDF Parsed Pages
            </span>
          </div>
        </div>

        {/* Metric 3: Verified Claims */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider">Verified Claims</span>
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {metrics?.verified_claims ?? 0}
            </span>
            <span className="text-xs text-slate-500 block mt-0.5">Source-Backed Facts</span>
          </div>
        </div>

        {/* Metric 4: Evidence Coverage */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-xs font-bold uppercase tracking-wider">Evidence Coverage</span>
            <span className="text-xs font-bold text-blue-600">{metrics?.evidence_coverage ?? 0}%</span>
          </div>
          <div className="mt-3">
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden mb-1">
              <div 
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(metrics?.evidence_coverage ?? 0, 100)}%` }}
              ></div>
            </div>
            <span className="text-[11px] text-slate-500 block">Verified Claims Coverage</span>
          </div>
        </div>

      </div>

      {/* Secondary Intelligence Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        {/* Metric 5: Contradictions */}
        <div 
          onClick={() => onNavigateTab('contradictions')}
          className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm cursor-pointer hover:border-red-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Contradictions</span>
            <ShieldAlert className="w-4 h-4 text-red-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-xl font-bold text-red-600 dark:text-red-400">
              {metrics?.contradictions ?? 0}
            </span>
            <span className="text-[10px] text-slate-400">Review Mismatches</span>
          </div>
        </div>

        {/* Metric 6: Missing Information */}
        <div 
          onClick={() => onNavigateTab('missing-info')}
          className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm cursor-pointer hover:border-amber-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Missing Info</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-xl font-bold text-amber-600 dark:text-amber-400">
              {metrics?.missing_information ?? 0}
            </span>
            <span className="text-[10px] text-slate-400">Required Artifacts</span>
          </div>
        </div>

        {/* Metric 7: Research Queries */}
        <div 
          onClick={() => onNavigateTab('research')}
          className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm cursor-pointer hover:border-blue-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Legal Research</span>
            <BookOpen className="w-4 h-4 text-blue-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-xl font-bold text-slate-900 dark:text-white">
              {metrics?.research_queries ?? 0}
            </span>
            <span className="text-[10px] text-slate-400">Grounded Searches</span>
          </div>
        </div>

        {/* Metric 8: Drafts Generated */}
        <div 
          onClick={() => onNavigateTab('drafting')}
          className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm cursor-pointer hover:border-blue-400 transition"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase">Legal Drafts</span>
            <FileEdit className="w-4 h-4 text-purple-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-xl font-bold text-slate-900 dark:text-white">
              {metrics?.drafts ?? 0}
            </span>
            <span className="text-[10px] text-slate-400">Grounded Notices</span>
          </div>
        </div>

      </div>

      {/* Evidence Health Status Indicators Legend */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Evidence Health & Verification Status Standards
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          
          <div className="flex items-center space-x-2 bg-emerald-50 dark:bg-emerald-950/40 p-2.5 rounded-lg border border-emerald-200 dark:border-emerald-800/60">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
            <div>
              <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 block">VERIFIED</span>
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400">Direct page text proof</span>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-yellow-50 dark:bg-yellow-950/40 p-2.5 rounded-lg border border-yellow-200 dark:border-yellow-800/60">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500 shrink-0"></span>
            <div>
              <span className="text-xs font-bold text-yellow-800 dark:text-yellow-300 block">PARTIAL</span>
              <span className="text-[10px] text-yellow-600 dark:text-yellow-400">Partial evidence match</span>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-orange-50 dark:bg-orange-950/40 p-2.5 rounded-lg border border-orange-200 dark:border-orange-800/60">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500 shrink-0"></span>
            <div>
              <span className="text-xs font-bold text-orange-800 dark:text-orange-300 block">UNSUPPORTED</span>
              <span className="text-[10px] text-orange-600 dark:text-orange-400">No page evidence found</span>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-red-50 dark:bg-red-950/40 p-2.5 rounded-lg border border-red-200 dark:border-red-800/60">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 shrink-0"></span>
            <div>
              <span className="text-xs font-bold text-red-800 dark:text-red-300 block">CONTRADICTED</span>
              <span className="text-[10px] text-red-600 dark:text-red-400">Cross-doc mismatch</span>
            </div>
          </div>

          <div className="flex items-center space-x-2 bg-slate-100 dark:bg-slate-800 p-2.5 rounded-lg border border-slate-300 dark:border-slate-700">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0"></span>
            <div>
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">INSUFFICIENT</span>
              <span className="text-[10px] text-slate-500">Zero-hallucination refusal</span>
            </div>
          </div>

        </div>
      </div>

      {/* Active & Recent Cases Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Active Case Workspaces</h2>
            <p className="text-xs text-slate-500">Every case maintains isolated document evidence and page indexes.</p>
          </div>
          <button
            onClick={() => onNavigateTab('cases')}
            className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center space-x-1"
          >
            <span>View All Cases</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Case ID</th>
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">Jurisdiction</th>
                <th className="px-4 py-3">Documents</th>
                <th className="px-4 py-3">Coverage</th>
                <th className="px-4 py-3">Contradictions</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {recentCases.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                    No cases created yet. Click "New Case" above to get started.
                  </td>
                </tr>
              ) : (
                recentCases.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="px-4 py-3 font-mono font-bold text-blue-600 dark:text-blue-400">{c.case_number}</td>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">{c.title}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{c.jurisdiction}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300 font-semibold">{c.documents_count ?? 0} PDFs</td>
                    <td className="px-4 py-3">
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{c.evidence_coverage ?? 0}%</span>
                    </td>
                    <td className="px-4 py-3">
                      {(c.contradictions_count ?? 0) > 0 ? (
                        <span className="px-2 py-0.5 bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 rounded-full font-bold text-[10px]">
                          {c.contradictions_count} Conflict(s)
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[10px]">0</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 rounded font-bold text-[10px]">
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => {
                          onSelectCase(c);
                          onNavigateTab('documents');
                        }}
                        className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white rounded text-xs font-semibold transition"
                      >
                        Open Case
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
