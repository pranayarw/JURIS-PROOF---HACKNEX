import React, { useEffect, useState } from 'react';
import { 
  FileText, ChevronLeft, ChevronRight, Search, CheckCircle2, 
  AlertTriangle, Bookmark, ExternalLink, ArrowLeft 
} from 'lucide-react';
import { getDocumentPages } from '../services/api';

interface DocumentViewerProps {
  documentId: number | null;
  onBack: () => void;
}

export const DocumentViewerPage: React.FC<DocumentViewerProps> = ({ documentId, onBack }) => {
  const [docData, setDocData] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (documentId) {
      loadPages(documentId);
    }
  }, [documentId]);

  const loadPages = async (docId: number) => {
    setLoading(true);
    try {
      const data = await getDocumentPages(docId);
      setDocData(data);
      if (data.pages && data.pages.length > 0) {
        setCurrentPage(1);
      }
    } catch (err) {
      console.error('Failed to load document pages:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!documentId) {
    return (
      <div className="p-8 text-center text-slate-400 space-y-3">
        <FileText className="w-12 h-12 mx-auto text-slate-500" />
        <p>No document selected. Please select a document from Document Management to open the viewer.</p>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-lg"
        >
          Go to Document Management
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-12 text-center text-slate-400">
        Loading document pages and evidence analysis...
      </div>
    );
  }

  const pages = docData?.pages || [];
  const activePageObj = pages.find((p: any) => p.page_number === currentPage) || pages[0];

  return (
    <div className="space-y-4">
      
      {/* Header bar */}
      <div className="flex items-center justify-between bg-white dark:bg-slate-900 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-600 dark:text-slate-300 transition"
            title="Back to Documents"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div>
            <h1 className="text-sm font-bold text-slate-900 dark:text-white flex items-center space-x-2">
              <FileText className="w-4 h-4 text-blue-600" />
              <span>{docData?.document_name}</span>
            </h1>
            <span className="text-[11px] text-slate-500">
              Total {docData?.page_count} page(s) • PyMuPDF Extracted Text
            </span>
          </div>
        </div>

        {/* Page Navigation Controls */}
        <div className="flex items-center space-x-2">
          <button
            disabled={currentPage <= 1}
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            className="p-1.5 bg-slate-100 dark:bg-slate-800 disabled:opacity-40 rounded-lg text-slate-700 dark:text-slate-300"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="text-xs font-bold text-slate-700 dark:text-slate-300 px-2">
            Page {currentPage} of {docData?.page_count || 1}
          </span>

          <button
            disabled={currentPage >= (docData?.page_count || 1)}
            onClick={() => setCurrentPage((p) => Math.min(p + 1, docData?.page_count || 1))}
            className="p-1.5 bg-slate-100 dark:bg-slate-800 disabled:opacity-40 rounded-lg text-slate-700 dark:text-slate-300"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 3-Panel Document Viewer Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-[600px]">
        
        {/* LEFT PANEL: Pages Selector */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3 space-y-2 overflow-y-auto max-h-[700px]">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
            Pages
          </h3>
          <div className="space-y-1">
            {pages.map((p: any) => {
              const isSelected = p.page_number === currentPage;
              return (
                <button
                  key={p.page_number}
                  onClick={() => setCurrentPage(p.page_number)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold flex items-center justify-between transition ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span>Page {p.page_number}</span>
                  <span className="text-[10px] opacity-75">{p.chunks_count} chunks</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* CENTER PANEL: Actual Document Page Text */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col justify-between space-y-4">
          
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-500 uppercase">
                Page {currentPage} Content
              </span>
              <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded font-mono">
                {activePageObj?.sections?.join(' | ') || 'Document Body'}
              </span>
            </div>

            {/* Document Text Render Box */}
            <div className="prose dark:prose-invert max-w-none text-xs leading-relaxed text-slate-800 dark:text-slate-200 font-serif whitespace-pre-wrap p-4 bg-slate-50 dark:bg-slate-950/60 rounded-lg border border-slate-200 dark:border-slate-800 min-h-[480px]">
              {activePageObj?.text || (
                <div className="text-slate-400 italic text-center py-12">
                  {docData?.is_scanned 
                    ? 'This document appears to be scanned. OCR is required to extract searchable text.'
                    : 'No text extracted for this page.'}
                </div>
              )}
            </div>
          </div>

          <div className="text-[11px] text-slate-400 flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
            <span>Preserved PyMuPDF Page #{currentPage}</span>
            <span>Source Truth Grounding Active</span>
          </div>
        </div>

        {/* RIGHT PANEL: Evidence, Claims & Citations */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-4 overflow-y-auto max-h-[700px]">
          
          <div>
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Extracted Claims on Page {currentPage}
            </h3>
            
            {docData?.claims?.filter((c: any) => c.page_number === currentPage).length === 0 ? (
              <p className="text-xs text-slate-400 py-3 italic">
                No major claims extracted from Page {currentPage} yet.
              </p>
            ) : (
              <div className="space-y-2">
                {docData?.claims
                  ?.filter((c: any) => c.page_number === currentPage)
                  .map((claim: any) => (
                    <div
                      key={claim.id}
                      className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="font-bold text-blue-600 dark:text-blue-400">{claim.category}</span>
                        <span className="px-1.5 py-0.2 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded font-bold">
                          {claim.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                        "{claim.text}"
                      </p>
                    </div>
                  ))}
              </div>
            )}
          </div>

          {/* All Page Citations & Jumping */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              Document Citations Index
            </h3>
            
            <div className="space-y-2">
              {docData?.claims?.map((claim: any) => (
                <div
                  key={claim.id}
                  onClick={() => setCurrentPage(claim.page_number)}
                  className={`p-2.5 rounded-lg border text-xs cursor-pointer transition ${
                    claim.page_number === currentPage
                      ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-800'
                      : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                    <span className="font-bold text-slate-700 dark:text-slate-300">Page {claim.page_number} Citation</span>
                    <span className="text-blue-600 dark:text-blue-400 font-semibold hover:underline">Jump to Page</span>
                  </div>
                  <p className="text-slate-700 dark:text-slate-300 line-clamp-2">
                    {claim.text}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
