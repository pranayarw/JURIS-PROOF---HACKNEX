import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, JSON, Float
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="Analyst") # Admin, Analyst, Law Enforcement, Government, Public
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    cases = relationship("Case", back_populates="creator", cascade="all, delete-orphan")

class Case(Base):
    __tablename__ = "cases"

    id = Column(Integer, primary_key=True, index=True)
    case_number = Column(String, unique=True, index=True, nullable=False)
    title = Column(String, nullable=False)
    case_type = Column(String, nullable=False, default="Commercial / Contract") # Contract, Criminal, Intellectual Property, Civil, Regulatory
    jurisdiction = Column(String, nullable=False, default="High Court")
    status = Column(String, default="Active") # Active, Under Review, Closed, Archived
    description = Column(Text, nullable=True)
    parties = Column(JSON, nullable=True) # list of parties e.g. ["Plaintiff: ABC Corp", "Defendant: XYZ Ltd"]
    tags = Column(JSON, nullable=True)
    creator_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    creator = relationship("User", back_populates="cases")
    documents = relationship("Document", back_populates="case", cascade="all, delete-orphan")
    chunks = relationship("DocumentChunk", back_populates="case", cascade="all, delete-orphan")
    claims = relationship("Claim", back_populates="case", cascade="all, delete-orphan")
    evidences = relationship("Evidence", back_populates="case", cascade="all, delete-orphan")
    citations = relationship("Citation", back_populates="case", cascade="all, delete-orphan")
    contradictions = relationship("Contradiction", back_populates="case", cascade="all, delete-orphan")
    missing_information = relationship("MissingInformation", back_populates="case", cascade="all, delete-orphan")
    events = relationship("CaseEvent", back_populates="case", cascade="all, delete-orphan")
    chat_messages = relationship("ChatMessage", back_populates="case", cascade="all, delete-orphan")
    drafts = relationship("LegalDraft", back_populates="case", cascade="all, delete-orphan")
    research_queries = relationship("ResearchQuery", back_populates="case", cascade="all, delete-orphan")

class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    document_name = Column(String, nullable=False)
    original_filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_type = Column(String, default="PDF")
    file_size = Column(Integer, default=0) # bytes
    page_count = Column(Integer, default=0)
    upload_date = Column(DateTime, default=datetime.datetime.utcnow)
    processing_status = Column(String, default="ready") # uploading, validating, processing, extracting, indexing, ready, failed
    processing_error = Column(Text, nullable=True)
    source_type = Column(String, default="Primary Case File")
    is_scanned = Column(Boolean, default=False)

    case = relationship("Case", back_populates="documents")
    chunks = relationship("DocumentChunk", back_populates="document", cascade="all, delete-orphan")

class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    page_number = Column(Integer, nullable=False) # 1-based page index
    chunk_index = Column(Integer, nullable=False)
    section = Column(String, nullable=True)
    text = Column(Text, nullable=False)

    document = relationship("Document", back_populates="chunks")
    case = relationship("Case", back_populates="chunks")

class Claim(Base):
    __tablename__ = "claims"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    text = Column(Text, nullable=False)
    category = Column(String, default="Factual Claim") # Factual Claim, Payment Terms, Termination, Obligation, Liability
    verification_status = Column(String, default="UNSUPPORTED") # VERIFIED, PARTIALLY SUPPORTED, UNSUPPORTED, CONTRADICTED, INSUFFICIENT EVIDENCE
    confidence = Column(Float, default=0.0)
    reasoning = Column(Text, nullable=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    page_number = Column(Integer, nullable=True)
    section = Column(String, nullable=True)

    case = relationship("Case", back_populates="claims")
    evidences = relationship("Evidence", back_populates="claim", cascade="all, delete-orphan")

class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    claim_id = Column(Integer, ForeignKey("claims.id", ondelete="CASCADE"), nullable=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    page_number = Column(Integer, nullable=False)
    section = Column(String, nullable=True)
    excerpt_text = Column(Text, nullable=False)
    relevance_score = Column(Float, default=1.0)

    case = relationship("Case", back_populates="evidences")
    claim = relationship("Claim", back_populates="evidences")

class Citation(Base):
    __tablename__ = "citations"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    claim_id = Column(Integer, ForeignKey("claims.id", ondelete="CASCADE"), nullable=True)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=False)
    page_number = Column(Integer, nullable=False)
    section = Column(String, nullable=True)
    citation_text = Column(Text, nullable=False)
    verification_status = Column(String, default="VERIFIED") # VERIFIED, PARTIALLY SUPPORTED, UNSUPPORTED, CONTRADICTED

    case = relationship("Case", back_populates="citations")

class Contradiction(Base):
    __tablename__ = "contradictions"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    claim_a = Column(Text, nullable=False)
    claim_b = Column(Text, nullable=False)
    doc_a_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=True)
    page_a = Column(Integer, nullable=True)
    doc_b_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=True)
    page_b = Column(Integer, nullable=True)
    status = Column(String, default="CRITICAL") # CRITICAL, REVIEW, RESOLVED

    case = relationship("Case", back_populates="contradictions")

class MissingInformation(Base):
    __tablename__ = "missing_information"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    item_name = Column(String, nullable=False)
    why_required = Column(Text, nullable=False)
    priority = Column(String, default="HIGH") # HIGH, MEDIUM, LOW
    related_claim_id = Column(Integer, ForeignKey("claims.id", ondelete="SET NULL"), nullable=True)
    recommended_action = Column(Text, nullable=False)
    status = Column(String, default="OPEN") # OPEN, OBTAINED, WAIVED

    case = relationship("Case", back_populates="missing_information")

class CaseEvent(Base):
    __tablename__ = "case_events"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    date_str = Column(String, nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    document_id = Column(Integer, ForeignKey("documents.id", ondelete="CASCADE"), nullable=True)
    page_number = Column(Integer, nullable=True)
    parties_involved = Column(JSON, nullable=True)

    case = relationship("Case", back_populates="events")

class LegalSource(Base):
    __tablename__ = "legal_sources"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    source_type = Column(String, nullable=False) # statute, precedent, regulation, secondary
    authority_level = Column(String, default="HIGH") # HIGH, MEDIUM, LOW
    section_reference = Column(String, nullable=True)
    summary = Column(Text, nullable=False)
    url_or_citation = Column(String, nullable=True)

class ResearchQuery(Base):
    __tablename__ = "research_queries"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    question = Column(Text, nullable=False)
    response_json = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    case = relationship("Case", back_populates="research_queries")

class LegalDraft(Base):
    __tablename__ = "legal_drafts"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    title = Column(String, nullable=False)
    draft_type = Column(String, default="Notice") # Contract Summary, Legal Notice, Case Summary, Formal Letter
    content = Column(Text, nullable=False)
    verified_facts = Column(JSON, nullable=True)
    missing_info_flags = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    case = relationship("Case", back_populates="drafts")

class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(String, default="default")
    sender = Column(String, nullable=False) # user, assistant
    message = Column(Text, nullable=False)
    verification_status = Column(String, default="VERIFIED") # VERIFIED, PARTIALLY SUPPORTED, CONTRADICTED, INSUFFICIENT EVIDENCE
    citations = Column(JSON, nullable=True)
    supporting_evidence = Column(JSON, nullable=True)
    missing_info = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    case = relationship("Case", back_populates="chat_messages")

class EvaluationResult(Base):
    __tablename__ = "evaluation_results"

    id = Column(Integer, primary_key=True, index=True)
    test_name = Column(String, nullable=False)
    metrics = Column(JSON, nullable=False) # groundedness, retrieval_quality, citation_accuracy, zero_hallucination_score
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class PublicHelpResource(Base):
    __tablename__ = "public_help_resources"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    category = Column(String, nullable=False) # Evidence Organization, Legal Preparation, Official Helplines
    content = Column(Text, nullable=False)
    official_source = Column(String, nullable=True)
