import React from 'react';
import { Share2, Briefcase, FileText, AlertTriangle, Users, BookOpen } from 'lucide-react';
import { Case } from '../services/api';

interface RelationshipMapProps {
  activeCase: Case | null;
}

export const RelationshipMapPage: React.FC<RelationshipMapProps> = ({ activeCase }) => {
  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to view the Case Relationship Map.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Share2 className="w-5 h-5 text-blue-600" />
            <span>Case Relationship Map</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Hierarchical relationship mapping connecting Case Entities, Uploaded Documents, Claims, Events, and Authorities.
          </p>
        </div>
      </div>

      {/* Relationship Diagram Tree */}
      <div className="bg-white dark:bg-slate-900 p-8 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-8">
        
        {/* Level 1: Root Case Node */}
        <div className="flex justify-center">
          <div className="bg-blue-600 text-white p-4 rounded-xl shadow-lg border-2 border-blue-400 flex items-center space-x-3">
            <Briefcase className="w-6 h-6" />
            <div>
              <span className="text-[10px] text-blue-200 uppercase font-bold tracking-wider block">Root Case Workspace</span>
              <h2 className="text-sm font-extrabold">{activeCase.case_number}: {activeCase.title}</h2>
            </div>
          </div>
        </div>

        <div className="w-0.5 h-8 bg-blue-300 dark:bg-blue-800 mx-auto"></div>

        {/* Level 2: Sub-branches */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          
          {/* Branch 1: Parties & Entities */}
          <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400 font-bold text-xs pb-2 border-b border-slate-200 dark:border-slate-700">
              <Users className="w-4 h-4" />
              <span>Parties / Entities</span>
            </div>
            <ul className="text-xs space-y-1 text-slate-700 dark:text-slate-300">
              {activeCase.parties?.map((p, i) => (
                <li key={i} className="bg-white dark:bg-slate-900 p-2 rounded border border-slate-200 dark:border-slate-800 font-medium">
                  {p}
                </li>
              )) || <li>No parties listed</li>}
            </ul>
          </div>

          {/* Branch 2: Source Documents */}
          <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center space-x-2 text-emerald-600 dark:text-emerald-400 font-bold text-xs pb-2 border-b border-slate-200 dark:border-slate-700">
              <FileText className="w-4 h-4" />
              <span>Source PDFs</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              {activeCase.documents_count ?? 0} uploaded document exhibits providing ground truth text.
            </p>
          </div>

          {/* Branch 3: Extracted Claims */}
          <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center space-x-2 text-purple-600 dark:text-purple-400 font-bold text-xs pb-2 border-b border-slate-200 dark:border-slate-700">
              <Share2 className="w-4 h-4" />
              <span>Extracted Claims</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Page-indexed factual claims verified against PyMuPDF document chunks.
            </p>
          </div>

          {/* Branch 4: Statutory Authorities */}
          <div className="bg-slate-50 dark:bg-slate-800/80 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center space-x-2 text-amber-600 dark:text-amber-400 font-bold text-xs pb-2 border-b border-slate-200 dark:border-slate-700">
              <BookOpen className="w-4 h-4" />
              <span>Legal Authorities</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Statutes, contract acts, and precedent court decisions linked to case claims.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
