import os
import random
import requests
import json
from typing import Dict, Any, List

class AIService:
    def __init__(self):
        # Allow configuring OpenAI or Gemini API Keys
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")

    def generate_threat_analysis(self, asset_type: str, asset_value: str, source: str) -> Dict[str, Any]:
        """
        Generates a comprehensive security threat report for a leaked asset.
        Supports OpenAI / Gemini if keys are provided, or defaults to a high-fidelity 
        rule-based mock generator.
        """
        if self.openai_api_key:
            try:
                # Call OpenAI
                headers = {
                    "Authorization": f"Bearer {self.openai_api_key}",
                    "Content-Type": "application/json"
                }
                payload = {
                    "model": "gpt-4-turbo",
                    "messages": [
                        {"role": "system", "content": "You are a cybersecurity intelligence analyst. Provide response in JSON format matching the schema: {threat_summary: str, threat_category: str, risk_score: int, attack_possibility: str, recommended_action: str, severity: str, confidence: int}"},
                        {"role": "user", "content": f"Analyze leak of {asset_type} '{asset_value}' in source '{source}'."}
                    ],
                    "response_format": {"type": "json_object"}
                }
                r = requests.post("https://api.openai.com/v1/chat/completures", headers=headers, json=payload, timeout=8)
                if r.status_code == 200:
                    return json.loads(r.json()["choices"][0]["message"]["content"])
            except Exception:
                pass

        # High-Fidelity Cyber-Security Policy/Rule-Based Engine (Fallback)
        # Provides deep, professional-grade analyses that look extremely realistic.
        analysis = {
            "threat_summary": f"Exposure of asset {asset_value} detected in public dataset '{source}'.",
            "threat_category": "Credential Spill / Data Leakage",
            "risk_score": 75,
            "attack_possibility": "High. Threat actors commonly automate credential stuffing campaigns, target account hijacking, and construct spear-phishing templates using leaked identifiers.",
            "recommended_action": "1. Rotate passwords immediately on all associated accounts.\n2. Enable Multi-Factor Authentication (MFA).\n3. Review recent access logs for anomalous geolocation logins.",
            "severity": "high",
            "confidence": 95
        }

        if asset_type == "email":
            analysis["threat_category"] = "Identity Theft & Phishing Risk"
            analysis["risk_score"] = 65
            analysis["severity"] = "high"
            analysis["attack_possibility"] = (
                f"Attackers can use '{asset_value}' as a target for targeted phishing (spear-phishing), business email compromise (BEC) "
                f"or search for correlated passwords in parallel dumps to perform credential stuffing against personal/work portals."
            )
            analysis["recommended_action"] = (
                "1. Immediately change passwords for accounts registered with this email.\n"
                "2. Force terminate active sessions on social, banking, and professional profiles.\n"
                "3. Enable hardware-bound 2FA (like YubiKey) or authenticator apps.\n"
                "4. Be vigilant for unsolicited security reset emails or authentication code messages."
            )
            analysis["confidence"] = 90

        elif asset_type == "password" or asset_type == "password_sim":
            analysis["threat_category"] = "Direct Account Hijack Vector"
            analysis["risk_score"] = 95
            analysis["severity"] = "critical"
            analysis["attack_possibility"] = (
                f"Extremely High. Leaked password credentials enable immediate automated account compromise via brute-force and credential reuse checks "
                f"across major services (Google, Microsoft, AWS, bank portals)."
            )
            analysis["recommended_action"] = (
                "1. Immediately run a full security sweep on all services matching this credential.\n"
                "2. Create a unique, randomly-generated passphrase using a secure password manager.\n"
                "3. Check for unauthorized sessions, connected third-party applications, and forwarding rules in your email settings."
            )
            analysis["confidence"] = 98

        elif asset_type == "api_key":
            analysis["threat_category"] = "Infrastructure Compromise & Billing Abuse"
            analysis["risk_score"] = 98
            analysis["severity"] = "critical"
            analysis["attack_possibility"] = (
                f"Instantaneous. Scrapers routinely sweep github/gitlab repositories and pastebin dumps for exposed API keys. "
                f"Exposed keys can be abused to steal customer databases, delete cloud infrastructure, or spin up expensive crypto-miners."
            )
            analysis["recommended_action"] = (
                "1. Revoke the API key '{asset_value}' in the target service provider portal immediately.\n"
                "2. Generate a new key and update server secrets using secure Vault storage (like AWS Secrets Manager or HashiCorp Vault).\n"
                "3. Scan past API usage records for billing spikes, unknown requests, and unauthorized data egress."
            )
            analysis["confidence"] = 99

        elif asset_type == "domain":
            analysis["threat_category"] = "Brand Impersonation & Typosquatting"
            analysis["risk_score"] = 55
            analysis["severity"] = "medium"
            analysis["attack_possibility"] = (
                f"Domain records exposure or sub-domain leak on '{asset_value}' enables DNS hijacking, domain takeover attacks, "
                f"or creation of lookalike malicious domains (typosquatting) to intercept company traffic."
            )
            analysis["recommended_action"] = (
                "1. Verify DNS zone records at your domain registrar to ensure no unauthorized DNS entries exist.\n"
                "2. Configure DNSSEC to guarantee domain authenticity.\n"
                "3. Set up strict DMARC, DKIM, and SPF policies to prevent spoofed email campaigns targeting customers."
            )
            analysis["confidence"] = 85

        elif asset_type == "phone":
            analysis["threat_category"] = "SIM Swapping & SMS Interception"
            analysis["risk_score"] = 70
            analysis["severity"] = "high"
            analysis["attack_possibility"] = (
                f"SIM swapping or SMS-based phishing (smishing). Attackers contact carriers social-engineering them to port the phone number, "
                f"allowing interception of SMS-based 2FA codes."
            )
            analysis["recommended_action"] = (
                "1. Contact your telecommunications provider and set an account security PIN/password to prevent unauthorized porting.\n"
                "2. Move from SMS-based 2FA to App-based Authenticator codes or hardware keys.\n"
                "3. Filter spam text messages and never click links in unexpected carrier SMS alerts."
            )
            analysis["confidence"] = 88

        elif asset_type == "employee_account":
            analysis["threat_category"] = "Corporate Network Intrusion"
            analysis["risk_score"] = 90
            analysis["severity"] = "critical"
            analysis["attack_possibility"] = (
                f"High severity corporate entry point. Compromised employee records allow lateral movement, access to private wikis, "
                f"corporate slack/emails, and potential deployment of ransomware."
            )
            analysis["recommended_action"] = (
                "1. Flag this employee profile in Active Directory / Okta.\n"
                "2. Trigger an immediate password reset and invalidate all active session tokens.\n"
                "3. Audit recent VPN/SSO access logs for this user account to ensure no unauthorized lateral access occurred."
            )
            analysis["confidence"] = 95

        return analysis

    def chat_advisor(self, message: str, context: List[Dict[str, str]] = None) -> str:
        """
        AI Security Advisor chatbot. Answers cyber security questions, incident guidelines,
        phishing questions, etc.
        """
        if self.openai_api_key:
            try:
                headers = {
                    "Authorization": f"Bearer {self.openai_api_key}",
                    "Content-Type": "application/json"
                }
                messages = [{"role": "system", "content": "You are SentinelBee, a JARVIS-style cybersecurity AI Advisor. You provide highly expert, crisp, actionable mitigation steps. Do not speak generally; be precise, professional, and slightly futuristic/sentinel-like."}]
                if context:
                    messages.extend(context)
                messages.append({"role": "user", "content": message})
                
                payload = {
                    "model": "gpt-4-turbo",
                    "messages": messages
                }
                r = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload, timeout=8)
                if r.status_code == 200:
                    return r.json()["choices"][0]["message"]["content"]
            except Exception:
                pass

        # Cyber security response chatbot intelligence engine (Deterministic Heuristic Fallback)
        msg_lower = message.lower()
        
        # Security guidance logic
        if "compromise" in msg_lower or "compromised" in msg_lower or "hacked" in msg_lower:
            return (
                "🚨 **INCIDENT RESPONSE PROTOCOL INITIATED**\n\n"
                "If you suspect a system or account compromise, proceed with this containment checklist:\n\n"
                "1. **Isolate Affected Systems**: If it is a local machine, disconnect it from the Wi-Fi/network immediately to prevent lateral spread.\n"
                "2. **Revoke and Reset Session Tokens**: Force logout all active sessions from the admin console or service dashboard. Change password to a unique 20+ character passphrase.\n"
                "3. **Revoke API Secrets**: If keys were exposed, immediately delete/deactivate them at the provider console.\n"
                "4. **Audit Logs**: Examine network connections, SMTP forwarding configurations, and OAuth app authorizations.\n"
                "5. **Notify Incident Response**: Report to your CISO or IT administrator. Preserve system logs and volatile RAM memory state if analysis is required."
            )
        elif "password" in msg_lower:
            return (
                "🔑 **BEE-GUARD PASSWORD SECURITY RECOMMENDATIONS**\n\n"
                "Passwords remain a high-value target for dark web actors. Adhere to these principles:\n\n"
                "- **Increase Entropy**: Length is more critical than special character complexity. A 4-word passphrase (e.g., `correct-horse-battery-staple`) is far harder to crack than a short complex one (`P@ss1`).\n"
                "- **Zero-Reuse Policy**: Never reuse passwords across domains. A single compromise on a low-security forum will lead to credential stuffing against your email or financial accounts.\n"
                "- **Deploy a Password Vault**: Use modern, audited managers (like 1Password, Bitwarden, or KeePassXC) to generate and store records.\n"
                "- **Eliminate SMS 2FA**: Switch to hardware FIDO2 keys (YubiKeys) or Authenticator applications (TOTP) to mitigate SIM swapping threats."
            )
        elif "phishing" in msg_lower or "email scan" in msg_lower or "fake login" in msg_lower:
            return (
                "🎣 **PHISHING & SOCIAL ENGINEERING MITIGATION**\n\n"
                "Phishing campaigns account for over 85% of initial corporate entry points. To stay protected:\n\n"
                "- **Inspect the Envelope**: Verify the sender's actual email address header (e.g., `security@paypaI-support.com` with a capital 'I' instead of 'l'—typosquatting).\n"
                "- **Avoid Shortened / Redirected Links**: Use url expanders to inspect destinations. Hover links to check the absolute target.\n"
                "- **Sandboxed Inspection**: Open suspicious attachments inside a virtual machine or dedicated sandbox (e.g., VirusTotal, Hybrid Analysis).\n"
                "- **Never input credentials under pressure**: Reputable organizations will never threaten immediate account suspension to force credential input."
            )
        elif "malware" in msg_lower or "ransomware" in msg_lower:
            return (
                "🦠 **MALWARE & RANSOMWARE MITIGATION BLUEPRINT**\n\n"
                "Malware payloads are delivered via email attachments, macro-enabled documents, or drive-by downloads. Active protection steps:\n\n"
                "- **Execute App Whitelisting**: Lock down environments to run only trusted, signed binaries. Block scripting hosts like PowerShell or WSL if not required.\n"
                "- **Enable EDR Agents**: Install endpoint detection (e.g., CrowdStrike Falcon, Microsoft Defender for Endpoint) to analyze process behaviors rather than static signatures.\n"
                "- **Offline Backups**: Ransomware will attempt to encrypt connected network drives. Ensure you maintain immutable, disconnected (air-gapped) backups."
            )
        elif "api key" in msg_lower or "token" in msg_lower:
            return (
                "🛡️ **SECURE CREDENTIAL MANAGEMENT PROTOCOL**\n\n"
                "Exposed API keys are the number one cause of cloud infrastructure breaches. Immediate steps:\n\n"
                "1. **Immediate Revocation**: Deactivate the token in the provider console.\n"
                "2. **Implement Secrets Managers**: Stop hardcoding credentials in git repositories. Use environment configurations, AWS Secrets Manager, or HashiCorp Vault.\n"
                "3. **Incorporate Pre-Commit Hooks**: Configure `git-secrets` or `trufflehog` to scan local commits and prevent secret pushes.\n"
                "4. **Restrict API Scope**: Apply the Principle of Least Privilege (e.g. limit key permissions to Read-Only or bind them to specific server IP addresses)."
            )
        else:
            return (
                f"🐝 **SENTINELBEE AI ONLINE**\n\n"
                f"Affirmative. I am monitoring the dark web indexes. You asked about: '{message}'\n\n"
                f"Please provide specific query details. I can assist you with:\n"
                f"• Incident Response Playbooks (compromises, ransomware)\n"
                f"• Password Policy configurations & Password Managers\n"
                f"• Phishing Domain checking & DNS integrity\n"
                f"• API Credential hardening techniques"
            )
            
    def predict_threats(self, domain: str) -> List[Dict[str, Any]]:
        """
        AI Threat Prediction - Generates simulated future threat forecasts 
        based on active threat vectors and domain attributes.
        """
        threat_vectors = [
            {"vector": "Domain Typosquatting Campaign", "probability": "High", "impact": "Brand Impersonation / Credential Phishing"},
            {"vector": "Subdomain Hijacking", "probability": "Medium", "impact": "DNS takeover and malicious payload distribution"},
            {"vector": "Employees Credential Stuffing", "probability": "High", "impact": "Unauthorised access to corporate email"},
            {"vector": "SSL Certificate Expiry Vulnerability", "probability": "Low", "impact": "Service disruption and MitM vulnerability"},
            {"vector": "API Endpoint Shadow Access", "probability": "Medium", "impact": "Data egress and API abuse"}
        ]
        
        # Select 2 to 3 threats dynamically
        random.seed(domain)
        selected = random.sample(threat_vectors, random.randint(2, 3))
        
        predictions = []
        for i, sv in enumerate(selected):
            predictions.append({
                "id": f"pred_{i}_{domain[:3]}",
                "vector": sv["vector"],
                "probability": sv["probability"],
                "impact": sv["impact"],
                "timeframe": "Next 14-30 days",
                "recommended_action": f"Review active configurations and implement security policies targeting {sv['vector'].lower()} immediately."
            })
            
        return predictions
