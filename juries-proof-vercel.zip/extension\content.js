// Pure JS SHA-256 Hash Implementation (Zero dependencies)
function sha256(ascii) {
  function rightRotate(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
  }
  
  var mathPow = Math.pow;
  var maxWord = mathPow(2, 32);
  var lengthProperty = 'length';
  var i, j; // Used as a counter across the whole file
  var result = '';

  var words = [];
  var asciiLength = ascii[lengthProperty];
  var hash = [];
  var k = [];
  var primeCounter = 0;

  var isPrime = function(n) {
    for (var factor = 2; factor * factor <= n; factor++) {
      if (n % factor === 0) return false;
    }
    return true;
  };

  var getFractionalBits = function(n) {
    return ((n - Math.floor(n)) * maxWord) | 0;
  };

  var getPrimes = function() {
    var candidate = 2;
    while (primeCounter < 64) {
      if (isPrime(candidate)) {
        if (primeCounter < 8) {
          hash[primeCounter] = getFractionalBits(mathPow(candidate, 1 / 2));
        }
        k[primeCounter] = getFractionalBits(mathPow(candidate, 1 / 3));
        primeCounter++;
      }
      candidate++;
    }
  };

  getPrimes();
  
  var wordsLength;
  var asciiBytes = [];
  for (i = 0; i < asciiLength; i++) {
    asciiBytes[i] = ascii.charCodeAt(i) & 0xff;
  }
  
  var bitsLength = asciiLength * 8;
  asciiBytes.push(0x80);
  while (asciiBytes[lengthProperty] % 64 !== 56) {
    asciiBytes.push(0);
  }
  
  for (i = 0; i < 8; i++) {
    asciiBytes.push((bitsLength >>> (56 - i * 8)) & 0xff);
  }
  
  for (i = 0; i < asciiBytes[lengthProperty]; i += 4) {
    words.push((asciiBytes[i] << 24) | (asciiBytes[i + 1] << 16) | (asciiBytes[i + 2] << 8) | asciiBytes[i + 3]);
  }
  
  wordsLength = words[lengthProperty];
  
  for (i = 0; i < wordsLength; i += 16) {
    var w = words.slice(i, i + 16);
    var oldHash = hash.slice(0);
    
    for (j = 0; w[lengthProperty] < 64; j++) {
      var w15 = w[w[lengthProperty] - 15];
      var w2 = w[w[lengthProperty] - 2];
      
      var s0 = rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3);
      var s1 = rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10);
      w.push((w[w[lengthProperty] - 16] + s0 + w[w[lengthProperty] - 7] + s1) | 0);
    }
    
    for (j = 0; j < 64; j++) {
      var a = hash[0], b = hash[1], c = hash[2], d = hash[3], e = hash[4], f = hash[5], g = hash[6], h = hash[7];
      
      var s0_prime = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
      var maj = (a & b) ^ (a & c) ^ (b & c);
      var t2 = (s0_prime + maj) | 0;
      
      var s1_prime = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
      var ch = (e & f) ^ (~e & g);
      var t1 = (h + s1_prime + ch + k[j] + w[j]) | 0;
      
      hash = [(t1 + t2) | 0, a, b, c, (d + t1) | 0, e, f, g];
    }
    
    for (j = 0; j < 8; j++) {
      hash[j] = (hash[j] + oldHash[j]) | 0;
    }
  }
  
  for (j = 0; j < 8; j++) {
    var hex = (hash[j] >>> 0).toString(16);
    while (hex[lengthProperty] < 8) hex = '0' + hex;
    result += hex;
  }
  
  return result;
}

// 1. Inject Floating Security Badge into target webpages
const API_URL = "http://localhost:8000/api";

async function injectSecurityBadge() {
  // Check if safe browsing config toggle is enabled
  chrome.storage.local.get(["toggleSafe"], async (cfg) => {
    if (cfg.toggleSafe === false) return;

    const hostname = window.location.hostname;
    // Skip localhost and internal chrome hosts
    if (hostname === "localhost" || hostname === "127.0.0.1" || hostname.includes("chrome-extension")) return;

    try {
      const res = await fetch(`${API_URL}/extension/domain?domain=${encodeURIComponent(hostname)}`);
      const data = await res.json();
      
      const badge = document.createElement("div");
      badge.id = "watchdog-security-badge";
      
      // Inline styles for glassmorphism cybersecurity badge
      badge.style.position = "fixed";
      badge.style.bottom = "20px";
      badge.style.right = "20px";
      badge.style.zIndex = "999999";
      badge.style.padding = "10px 16px";
      badge.style.fontSize = "10px";
      badge.style.fontFamily = "monospace";
      badge.style.fontWeight = "bold";
      badge.style.borderRadius = "4px";
      badge.style.boxShadow = "0 8px 32px rgba(0,0,0,0.8)";
      badge.style.cursor = "pointer";
      badge.style.transition = "all 0.3s ease";
      badge.style.display = "flex";
      badge.style.alignItems = "center";
      badge.style.gap = "8px";
      badge.style.backdropFilter = "blur(12px)";
      badge.style.webkitBackdropFilter = "blur(12px)";

      const isSafe = data.trust_score >= 80;
      
      if (isSafe) {
        badge.style.background = "rgba(16, 185, 129, 0.15)";
        badge.style.border = "1px solid rgba(16, 185, 129, 0.4)";
        badge.style.color = "#10b981";
        badge.innerHTML = `<span>✓</span> <span>SAFE DOMAIN (${data.trust_score})</span>`;
      } else if (data.trust_score >= 50) {
        badge.style.background = "rgba(245, 158, 11, 0.15)";
        badge.style.border = "1px solid rgba(245, 158, 11, 0.4)";
        badge.style.color = "#f59e0b";
        badge.innerHTML = `<span>⚠</span> <span>SUSPICIOUS POSTURE (${data.trust_score})</span>`;
      } else {
        badge.style.background = "rgba(239, 68, 68, 0.2)";
        badge.style.border = "1px solid rgba(239, 68, 68, 0.6)";
        badge.style.color = "#ef4444";
        badge.style.animation = "pulse 2s infinite";
        badge.innerHTML = `<span>⚡</span> <span>RISK ALERT (${data.trust_score})</span>`;
      }
      
      // Toggle detailed expansion on click
      let expanded = false;
      badge.addEventListener("click", () => {
        if (!expanded) {
          badge.innerHTML += ` <span style="border-left: 1px solid rgba(255,255,255,0.1); padding-left: 8px; margin-left: 4px; font-weight: normal; color: #94a3b8;">SSL: ${data.ssl_status} | Blacklist: ${data.blacklist_status}</span>`;
          expanded = true;
        } else {
          injectSecurityBadge(); // Re-render default state
          expanded = false;
        }
      });

      // Avoid double injection
      const oldBadge = document.getElementById("watchdog-security-badge");
      if (oldBadge) oldBadge.remove();

      document.body.appendChild(badge);
    } catch (e) {
      console.log("Failed to query watchdog reputation badge server.");
    }
  });
}

// 2. Listen to login forms for credential checking
function listenToLoginSubmissions() {
  document.addEventListener("submit", (event) => {
    chrome.storage.local.get(["togglePhish"], (cfg) => {
      if (cfg.togglePhish === false) return;

      const form = event.target;
      const inputs = form.querySelectorAll("input");
      
      let emailVal = "";
      
      // Parse fields looking for email addresses
      inputs.forEach((input) => {
        const val = input.value || "";
        if (input.type === "email" || val.includes("@")) {
          emailVal = val.trim();
        }
      });
      
      if (emailVal !== "") {
        const hashedEmail = sha256(emailVal);
        // Dispatch checking message to background script
        chrome.runtime.sendMessage({
          action: "checkCredentialsSpill",
          emailHash: hashedEmail,
          domain: window.location.hostname
        });
      }
    });
  });
}

// Initialize content protections
if (document.readyState === "complete" || document.readyState === "interactive") {
  injectSecurityBadge();
  listenToLoginSubmissions();
} else {
  window.addEventListener("DOMContentLoaded", () => {
    injectSecurityBadge();
    listenToLoginSubmissions();
  });
}
