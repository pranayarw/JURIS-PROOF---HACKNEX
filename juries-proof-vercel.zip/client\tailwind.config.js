/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cyber: {
          black: "#020204",
          dark: "#08090d",
          gray: "#12141c",
          lightgray: "#1e2230",
          cyan: "#00f0ff",
          purple: "#d946ef",
          violet: "#8b5cf6",
          red: "#ef4444",
          green: "#10b981",
          yellow: "#f59e0b"
        }
      },
      boxShadow: {
        "cyan-glow": "0 0 15px rgba(0, 240, 255, 0.4)",
        "purple-glow": "0 0 15px rgba(217, 70, 239, 0.4)",
        "red-glow": "0 0 15px rgba(239, 68, 68, 0.4)",
        "green-glow": "0 0 15px rgba(16, 185, 129, 0.4)",
        "card-glow": "0 8px 32px 0 rgba(0, 0, 0, 0.8)",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Fira Code", "monospace"]
      },
      backgroundImage: {
        "cyber-grid": "linear-gradient(to right, rgba(255, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.03) 1px, transparent 1px)",
        "radial-dark": "radial-gradient(circle at center, #0e111a 0%, #030407 100%)"
      }
    },
  },
  plugins: [],
}
