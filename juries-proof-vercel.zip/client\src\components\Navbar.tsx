import React from 'react';
import { Scale, Plus, ShieldCheck, Sun, Moon, Briefcase, ChevronDown } from 'lucide-react';
import { Case } from '../services/api';

interface NavbarProps {
  cases: Case[];
  activeCase: Case | null;
  onSelectCase: (c: Case) => void;
  onOpenCreateCaseModal: () => void;
  userRole: string;
  onRoleChange: (role: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cases,
  activeCase,
  onSelectCase,
  onOpenCreateCaseModal,
  userRole,
  onRoleChange,
  darkMode,
  onToggleDarkMode,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo & Title */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <img 
              src="/logo.png" 
              alt="JURIES PROOF Logo" 
              className="h-10 w-10 object-contain rounded-md"
              onError={(e) => {
                // Fallback icon if logo image fails to load
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            <div className="flex flex-col">
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 dark:text-white">
                  JURIES PROOF
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded border border-slate-300 dark:border-slate-700">
                  REAL PDF INTELLIGENCE
                </span>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium hidden sm:inline">
                Every legal claim. Every source. Every proof.
              </span>
            </div>
          </div>
        </div>

        {/* Case Selector Dropdown & Actions */}
        <div className="flex items-center space-x-3">
          
          {/* Active Case Selector */}
          <div className="relative group">
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer transition">
              <Briefcase className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 mr-2" />
              <div className="flex flex-col text-left mr-2">
                <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold">Active Case</span>
                <span className="truncate max-w-[140px] sm:max-w-[200px]">
                  {activeCase ? `${activeCase.case_number}: ${activeCase.title}` : 'Select / Create Case'}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>

            {/* Dropdown Menu */}
            <div className="absolute right-0 mt-1 w-72 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg shadow-xl py-2 hidden group-hover:block z-50">
              <div className="px-3 py-1.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 uppercase">Case Workspace</span>
                <button
                  onClick={onOpenCreateCaseModal}
                  className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center"
                >
                  <Plus className="w-3 h-3 mr-0.5" /> New Case
                </button>
              </div>

              <div className="max-h-56 overflow-y-auto">
                {cases.length === 0 ? (
                  <div className="px-3 py-3 text-xs text-slate-400 text-center">
                    No active cases found.<br />Create a case to begin.
                  </div>
                ) : (
                  cases.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => onSelectCase(c)}
                      className={`w-full text-left px-3 py-2 text-xs flex flex-col hover:bg-slate-50 dark:hover:bg-slate-800 transition ${
                        activeCase?.id === c.id ? 'bg-blue-50 dark:bg-slate-800/80 font-bold border-l-2 border-blue-600' : ''
                      }`}
                    >
                      <span className="text-slate-900 dark:text-white font-medium truncate">{c.title}</span>
                      <span className="text-[10px] text-slate-500 flex items-center justify-between">
                        <span>{c.case_number}</span>
                        <span className="px-1.5 py-0.2 bg-slate-200 dark:bg-slate-700 rounded text-[9px]">{c.status}</span>
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Create Case Button */}
          <button
            onClick={onOpenCreateCaseModal}
            className="hidden md:flex items-center space-x-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-3 py-2 rounded-lg shadow-sm transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Case</span>
          </button>

          {/* Role Switcher */}
          <div className="hidden lg:flex items-center space-x-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <select
              value={userRole}
              onChange={(e) => onRoleChange(e.target.value)}
              className="bg-transparent text-xs font-semibold focus:outline-none cursor-pointer text-slate-800 dark:text-slate-200"
            >
              <option value="Admin">Role: Admin</option>
              <option value="Analyst">Role: Analyst</option>
              <option value="Law Enforcement">Role: Law Enforcement</option>
              <option value="Government">Role: Government</option>
              <option value="Public">Role: Public Legal Help</option>
            </select>
          </div>

          {/* Theme Toggle Button */}
          <button
            onClick={onToggleDarkMode}
            className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"
            title="Toggle Light / Dark Mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>

        </div>

      </div>
    </header>
  );
};
