from sqlalchemy.orm import Session
from ..models import Claim, Citation, Document, DocumentChunk, Evidence

def verify_claim_against_evidence(claim_id: int, db: Session):
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        return {"error": "Claim not found"}

    evidences = db.query(Evidence).filter(Evidence.claim_id == claim_id).all()
    if not evidences:
        claim.verification_status = "UNSUPPORTED"
        claim.confidence = 0.0
        db.commit()
        return {
            "claim_id": claim_id,
            "verification_status": "UNSUPPORTED",
            "reasoning": "No supporting document evidence chunks linked to this claim."
        }

    # Verify matching text
    matched_count = 0
    total_evidences = len(evidences)
    
    for ev in evidences:
        chunk = db.query(DocumentChunk).filter(
            DocumentChunk.document_id == ev.document_id,
            DocumentChunk.page_number == ev.page_number
        ).first()
        if chunk and (ev.excerpt_text.lower() in chunk.text.lower() or claim.text.lower()[:30] in chunk.text.lower()):
            matched_count += 1

    match_ratio = matched_count / max(total_evidences, 1)

    if match_ratio >= 0.8:
        status = "VERIFIED"
    elif match_ratio > 0.3:
        status = "PARTIALLY SUPPORTED"
    else:
        status = "UNSUPPORTED"

    claim.verification_status = status
    claim.confidence = round(match_ratio, 2)
    db.commit()

    return {
        "claim_id": claim_id,
        "verification_status": status,
        "match_ratio": match_ratio,
        "evidences_count": total_evidences
    }


def verify_citation_against_source(citation_id: int, db: Session):
    citation = db.query(Citation).filter(Citation.id == citation_id).first()
    if not citation:
        return {"error": "Citation not found"}

    chunks = db.query(DocumentChunk).filter(
        DocumentChunk.document_id == citation.document_id,
        DocumentChunk.page_number == citation.page_number
    ).all()

    if not chunks:
        citation.verification_status = "UNSUPPORTED"
        db.commit()
        return {
            "citation_id": citation_id,
            "status": "UNSUPPORTED",
            "reasoning": f"Page {citation.page_number} does not contain extracted text."
        }

    page_full_text = " ".join([c.text.lower() for c in chunks])
    
    # Verify if snippet or cited text is present on the page
    snippet = citation.citation_text.lower()
    if len(snippet) > 20 and snippet[:30] in page_full_text or "page" in snippet:
        citation.verification_status = "VERIFIED"
    else:
        citation.verification_status = "PARTIALLY SUPPORTED"

    db.commit()

    return {
        "citation_id": citation_id,
        "status": citation.verification_status,
        "document_id": citation.document_id,
        "page_number": citation.page_number
    }
