import React, { useEffect, useState } from 'react';
import { Printer, Download, CheckCircle2, AlertTriangle, FileText } from 'lucide-react';
import { getCaseReview, getTimeline, getContradictions, Case } from '../services/api';

interface ReportsViewProps {
  activeCase: Case | null;
}

export const ReportsViewPage: React.FC<ReportsViewProps> = ({ activeCase }) => {
  const [review, setReview] = useState<any>(null);
  const [timeline, setTimeline] = useState<any[]>([]);
  const [contradictions, setContradictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeCase) {
      fetchReportData();
    }
  }, [activeCase]);

  const fetchReportData = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const r = await getCaseReview(activeCase.id);
      setReview(r);
      const t = await getTimeline(activeCase.id);
      setTimeline(t);
      const c = await getContradictions(activeCase.id);
      setContradictions(c);
    } catch (err) {
      console.error('Failed to load report data:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to generate Case Intelligence Reports.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header Controls */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between print:hidden">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Printer className="w-5 h-5 text-blue-600" />
            <span>Formal Legal Intelligence Case Report</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Print-ready comprehensive case intelligence report derived from verified PDF exhibits.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow transition"
        >
          <Printer className="w-4 h-4" />
          <span>Print / Save PDF Report</span>
        </button>
      </div>

      {/* Printable Report Document Container */}
      <div className="bg-white text-slate-900 p-8 rounded-xl border border-slate-200 shadow-lg space-y-6 font-serif max-w-4xl mx-auto print:shadow-none print:border-none print:p-0">
        
        {/* Report Header */}
        <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <img src="/logo.png" alt="Logo" className="w-8 h-8 object-contain" />
              <span className="font-sans font-black text-xl tracking-tight">JURIES PROOF</span>
            </div>
            <p className="text-xs font-sans text-slate-600">Evidence-First Legal Intelligence Audit Report</p>
          </div>

          <div className="text-right text-xs font-sans">
            <p className="font-mono font-bold text-blue-700">{activeCase.case_number}</p>
            <p className="text-slate-500">Date: {new Date().toLocaleDateString()}</p>
          </div>
        </div>

        {/* Case Metadata Section */}
        <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 font-sans text-xs space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div><span className="text-slate-500">Case Title:</span> <strong>{activeCase.title}</strong></div>
            <div><span className="text-slate-500">Jurisdiction:</span> <strong>{activeCase.jurisdiction}</strong></div>
            <div><span className="text-slate-500">Case Type:</span> <strong>{activeCase.case_type}</strong></div>
            <div><span className="text-slate-500">Status:</span> <strong>{activeCase.status}</strong></div>
          </div>
        </div>

        {/* Section 1: Executive Summary */}
        <div className="space-y-2">
          <h2 className="text-sm font-sans font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
            1. Executive Summary & Evidence Coverage
          </h2>
          <p className="text-xs leading-relaxed">
            {review?.summary || 'Case analysis completed across uploaded document exhibits.'}
          </p>
          <p className="text-xs font-sans font-semibold text-blue-700">
            Overall Evidence Coverage: {review?.evidence_coverage?.coverage_percentage ?? 0}% of claims verified against PDF text.
          </p>
        </div>

        {/* Section 2: Key Facts & Page Citations */}
        <div className="space-y-2">
          <h2 className="text-sm font-sans font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
            2. Verified Key Facts & Exhibit Citations
          </h2>
          <div className="space-y-2 text-xs">
            {review?.key_facts?.map((f: any, idx: number) => (
              <div key={idx} className="p-2.5 bg-slate-50 rounded border border-slate-200 space-y-1">
                <p className="font-serif font-medium">"{f.fact}"</p>
                <div className="flex justify-between font-sans text-[10px] text-slate-600">
                  <span>CITED SOURCE: {f.source}</span>
                  <span className="font-bold text-emerald-700">{f.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Contradictions */}
        <div className="space-y-2">
          <h2 className="text-sm font-sans font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
            3. Cross-Document Contradiction Analysis
          </h2>
          {contradictions.length === 0 ? (
            <p className="text-xs font-sans text-slate-500">Zero contradictions detected across case document exhibits.</p>
          ) : (
            <div className="space-y-2 text-xs">
              {contradictions.map((c: any, idx: number) => (
                <div key={idx} className="p-3 bg-red-50 rounded border border-red-200 space-y-1 font-sans">
                  <span className="font-bold text-red-700">CONTRADICTION: {c.title}</span>
                  <p className="text-[11px] text-slate-700">{c.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Section 4: Chronological Timeline */}
        <div className="space-y-2">
          <h2 className="text-sm font-sans font-bold text-slate-900 uppercase tracking-wider border-b border-slate-200 pb-1">
            4. Chronological Case Event Timeline
          </h2>
          <div className="space-y-2 text-xs font-sans">
            {timeline.map((evt: any, idx: number) => (
              <div key={idx} className="flex items-start space-x-3 text-xs border-b border-slate-100 pb-2">
                <span className="font-mono font-bold text-blue-700 w-28 shrink-0">{evt.date}</span>
                <div>
                  <p className="font-bold">{evt.title}</p>
                  <p className="text-slate-600 text-[11px]">{evt.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Report Footer */}
        <div className="pt-6 border-t-2 border-slate-900 text-[10px] font-sans text-slate-500 flex justify-between">
          <span>JURIES PROOF • Evidence-First Agentic Legal Intelligence</span>
          <span>End of Formal Case Report</span>
        </div>

      </div>

    </div>
  );
};
