import React, { useState } from 'react';
import { BookOpen, Search, ShieldCheck, FileText, Scale } from 'lucide-react';
import { performLegalResearch, Case } from '../services/api';

interface LegalResearchProps {
  activeCase: Case | null;
}

export const LegalResearchPage: React.FC<LegalResearchProps> = ({ activeCase }) => {
  const [query, setQuery] = useState('');
  const [researchResult, setResearchResult] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);

  const handleResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || !activeCase) return;

    setLoading(true);
    try {
      const data = await performLegalResearch(activeCase.id, query.trim());
      setResearchResult(data);
    } catch (err) {
      console.error('Legal research failed:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to perform grounded legal research.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <span>Grounded Legal Research Engine</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Connects case document evidence to verified statutory provisions and legal authorities without fabricated citations.
          </p>
        </div>
      </div>

      {/* Query Search Form */}
      <form onSubmit={handleResearch} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center space-x-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. Compensation rules for contractual breach under Section 73..."
            className="w-full pl-9 pr-4 py-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-5 py-3 rounded-lg shadow transition shrink-0"
        >
          {loading ? 'Searching Authorities...' : 'Search Legal Sources'}
        </button>
      </form>

      {/* Results Display */}
      {researchResult && (
        <div className="space-y-6">
          
          {/* Grounded Case Answer */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-500 uppercase">Case Grounded Analysis</span>
              <span className="px-2.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold text-[10px] rounded">
                {researchResult.verification_status}
              </span>
            </div>

            <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed font-sans whitespace-pre-wrap">
              {researchResult.answer}
            </p>
          </div>

          {/* Legal Authorities Grid */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center space-x-2">
              <Scale className="w-4 h-4 text-amber-500" />
              <span>Verified Legal Authorities & Statutes</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {researchResult.legal_sources?.map((src: any, idx: number) => (
                <div key={idx} className="p-4 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-600 dark:text-blue-400">{src.title}</span>
                    <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 rounded font-bold text-[9px]">
                      {src.authority} Authority
                    </span>
                  </div>

                  <p className="text-[11px] font-mono font-semibold text-slate-700 dark:text-slate-300">
                    {src.section}
                  </p>

                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {src.summary}
                  </p>

                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700 text-[10px] text-slate-400">
                    Citation: {src.citation}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
