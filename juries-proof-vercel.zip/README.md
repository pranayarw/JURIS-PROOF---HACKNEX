# Dark Web Watchdog 🐝

> **Tagline:** *"Know Before Hackers Do."*

Dark Web Watchdog is a production-quality cybersecurity threat intelligence prototype. Inspired by Microsoft Defender, CrowdStrike Falcon, and Splunk, it features a high-contrast true black cybernetic dashboard, real-time threat indicators, a mock leak database checker, an interactive AI Incident containment chatbot (SentinelBee), and a companion Chrome/Edge extension.

---

## 🚀 Key Features

1. **Futuristic Diagnostics Dashboard**: Circular neon risk score integrity meters, Recharts timelines, SVGs global threat maps, and administrative service health panels.
2. **Dynamic Leak Checker**: Automatically matches monitored parameters (emails, subdomains, API keys, phone numbers, corporate AD accounts) against past simulated breach spills (e.g. Adobe, LinkedIn, Canva).
3. **AI Threat Deconstruction**: Auto-generates detailed risk scores, attack likelihood, and custom containment playbooks.
4. **SentinelBee Security Advisor**: Typing-animated incident chatbot offering step-by-step containment checklists, credential security rules, and phishing auditing techniques.
5. **PDF Reports compiler**: Aggregates monitoring lists and active threat indices into downloadable, board-ready audit reports.
6. **Admin Injector Console**: Instate administrative privilege overrides, sweep raw system telemetry logs, and simulate mock breaches in real-time.
7. **Companion Browser Extension (Manifest V3)**:
   - Floating glassmorphic domain reputation badge injected into visited pages.
   - Zero-Storage local hashing of login fields matching database breaches.
   - Telemetry sync (domain alerts, suspicious downloads) straight back to your central dashboard database.

---

## 🛠️ Technology Stack

* **Frontend**: React (v19), Vite, TypeScript, Tailwind CSS, Framer Motion, Lucide Icons, Recharts, React Query.
* **Backend**: FastAPI, Python (3.10+), SQLAlchemy.
* **Database**: SQLite (local development zero-setup) / PostgreSQL (deployment ready).
* **Browser Extension**: Vanilla JS, Manifest V3.

---

## 📁 Repository Structure

```
/
├── client/          # Vite + React + TypeScript Dashboard client
├── server/          # FastAPI Python API server
├── extension/       # Manifest V3 Chrome/Edge companion extension
├── shared/          # Seed breach database (mock_breaches.json)
├── docker-compose.yml
└── README.md
```

---

## ⚙️ Installation & Setup

### 1. Prerequisites
Ensure you have the following installed:
* [Node.js](https://nodejs.org/) (v18+)
* [Python](https://www.python.org/) (v3.10+)
* Google Chrome or Microsoft Edge browser (for extension sideloading)

---

### 2. Backend Setup
1. Open your terminal and navigate to the `server` directory:
   ```bash
   cd server
   ```
2. Create and activate a Python virtual environment:
   ```bash
   python -m venv venv
   # On Windows:
   venv\Scripts\activate
   # On macOS/Linux:
   source venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Copy the environment template:
   ```bash
   cp ../.env.example .env
   ```
5. Start the FastAPI local server:
   ```bash
   uvicorn app.main:app --reload --port 8000
   ```
   *The server will run on **`http://localhost:8000`**.*
   *Note: On first startup, the server automatically seeds the SQLite database (`darkwatchdog.db`) with mock asset listings, threat matches, alerts, and log events.*

---

### 3. Frontend Dashboard Setup
1. Open a new terminal window and navigate to the `client` directory:
   ```bash
   cd client
   ```
2. Install npm packages:
   ```bash
   npm install
   ```
3. Start the Vite local development server:
   ```bash
   npm run dev
   ```
   *The dashboard will be active on **`http://localhost:5173`**.*

---

### 4. Side-Loading the Browser Extension
1. Open Chrome or Edge and navigate to **`chrome://extensions/`**.
2. Turn on the **Developer mode** toggle switch in the top-right corner.
3. Click the **Load unpacked** button in the top-left.
4. Select the **`extension/`** folder inside this repository.
5. The **Bee-Watch Sentinel** icon will now appear in your browser taskbar!

---

## 🔑 Prefilled Demo Logins

To simplify your testing, the portal features pre-filled credentials:
* **Demo User Account**:
  * Email: `demo@watchdog.io`
  * Password: `user123`
  * *Provides full access to dashboard, alerts, settings, reports, and AI advisor.*
* **Admin Account**:
  * Email: `admin@watchdog.io`
  * Password: `admin123`
  * *Unlocks the administrative overrides panel.*

---

## 🔒 Security & Privacy Notice
This is a **hackathon prototype**. It does *not* query deep dark-net Tor websites or perform active network crawling. The credentials breach search checks against a pre-loaded local simulated database (`shared/mock_breaches.json`) to keep search data secure.
