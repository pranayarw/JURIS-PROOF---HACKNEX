// Local configuration base
const API_URL = "http://localhost:8000/api";

document.addEventListener("DOMContentLoaded", async () => {
  const safetyScoreEl = document.getElementById("safetyScore");
  const sslStatusEl = document.getElementById("sslStatus");
  const repStatusEl = document.getElementById("repStatus");
  const warningCardEl = document.getElementById("warningCard");
  const warningTextEl = document.getElementById("warningText");
  const logBoxEl = document.getElementById("logBox");
  const scanBtn = document.getElementById("scanBtn");

  // Load active tab hostname
  let activeTabHostname = "unknown";
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs && tabs[0] && tabs[0].url) {
      const urlObj = new URL(tabs[0].url);
      activeTabHostname = urlObj.hostname;
      logBoxEl.innerText += `\n[TARGET] Hooked domain: ${activeTabHostname}`;
    }
  } catch (err) {
    logBoxEl.innerText += `\n[ERROR] Unable to extract tab details.`;
  }

  // Fetch reputation metrics
  if (activeTabHostname !== "unknown" && activeTabHostname !== "") {
    try {
      const res = await fetch(`${API_URL}/extension/domain?domain=${encodeURIComponent(activeTabHostname)}`);
      const data = await res.json();
      
      // Update UI
      safetyScoreEl.innerText = `${data.trust_score}`;
      
      // Clear score classes
      safetyScoreEl.className = "score-val " + data.risk_indicator;
      sslStatusEl.innerText = data.ssl_status;
      repStatusEl.innerText = data.blacklist_status === "Clean" ? "Authorized" : "Flagged Malicious";
      repStatusEl.className = data.blacklist_status === "Clean" ? "green" : "red";
      
      if (data.trust_score < 50) {
        warningCardEl.style.display = "block";
        warningTextEl.innerText = data.reasons.join(", ");
        logBoxEl.innerText += `\n[ALERT] Threat indicators found! Core risk high.`;
      } else {
        warningCardEl.style.display = "none";
        logBoxEl.innerText += `\n[SUCCESS] Domain reputation clear.`;
      }
    } catch (err) {
      logBoxEl.innerText += `\n[ERROR] Connection to FastAPI sentinel server failed. Using local heuristic offline.`;
      // Offline fallback mock
      safetyScoreEl.innerText = "85";
      safetyScoreEl.className = "score-val green";
      sslStatusEl.innerText = "Valid cert";
      repStatusEl.innerText = "Secure";
      repStatusEl.className = "green";
    }
  }

  // Load checkbox configurations from chrome storage
  const toggles = ["toggleSafe", "togglePhish", "toggleDownloads", "toggleSync"];
  toggles.forEach(id => {
    const el = document.getElementById(id);
    chrome.storage.local.get([id], (result) => {
      if (result[id] !== undefined) {
        el.checked = result[id];
      }
    });

    el.addEventListener("change", () => {
      chrome.storage.local.set({ [id]: el.checked }, () => {
        logBoxEl.innerText += `\n[CONFIG] Changed ${id} state: ${el.checked}`;
      });
    });
  });

  // Action scan active domain button
  scanBtn.addEventListener("click", async () => {
    logBoxEl.innerText += `\n[SCAN] Initiating scrutinizer scans on ${activeTabHostname}...`;
    scanBtn.disabled = true;

    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs || !tabs[0]) return;

      const res = await fetch(`${API_URL}/extension/domain?domain=${encodeURIComponent(activeTabHostname)}`);
      const data = await res.json();
      
      setTimeout(() => {
        logBoxEl.innerText += `\n[SCAN] Trust Score: ${data.trust_score}/100`;
        logBoxEl.innerText += `\n[SCAN] Phishing Probability: ${data.phishing_probability}%`;
        logBoxEl.innerText += `\n[SCAN] Complete. Synced telemetry log.`;
        scanBtn.disabled = false;
        
        // Scroll logs to bottom
        logBoxEl.scrollTop = logBoxEl.scrollHeight;
      }, 1000);
    } catch (err) {
      logBoxEl.innerText += `\n[SCAN] Error querying domain. Scan aborted.`;
      scanBtn.disabled = false;
    }
  });
});
