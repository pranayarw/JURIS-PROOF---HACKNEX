import sys
import os

# Add server directory to python path for Vercel Serverless execution
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))

from app.main import app

# Export app ASGI handler for Vercel
handler = app
