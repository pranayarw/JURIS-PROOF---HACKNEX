import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

export default api;

export interface Case {
  id: number;
  case_number: string;
  title: string;
  case_type: string;
  jurisdiction: string;
  status: string;
  description: string;
  parties: string[];
  documents_count?: number;
  contradictions_count?: number;
  missing_info_count?: number;
  evidence_coverage?: number;
  created_at?: string;
}

export interface DocumentItem {
  id: number;
  case_id: number;
  document_name: string;
  file_type: string;
  file_size: number;
  page_count: number;
  upload_date: string;
  processing_status: 'uploading' | 'validating' | 'processing' | 'extracting' | 'indexing' | 'ready' | 'failed';
  processing_error?: string;
  is_scanned?: boolean;
}

export interface DashboardMetrics {
  active_cases: number;
  documents_processed: number;
  verified_claims: number;
  evidence_coverage: number;
  contradictions: number;
  missing_information: number;
  research_queries: number;
  drafts: number;
}

export const getDashboardMetrics = async (caseId?: number): Promise<DashboardMetrics> => {
  const res = await api.get('/dashboard/metrics', { params: { case_id: caseId } });
  return res.data;
};

export const getCases = async (): Promise<Case[]> => {
  const res = await api.get('/cases');
  return res.data;
};

export const createCase = async (formData: FormData): Promise<Case> => {
  const res = await api.post('/cases', formData);
  return res.data;
};

export const getCaseDetail = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}`);
  return res.data;
};

export const deleteCase = async (caseId: number) => {
  const res = await api.delete(`/cases/${caseId}`);
  return res.data;
};

export const uploadPdfDocument = async (caseId: number, file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  const res = await api.post(`/cases/${caseId}/documents/upload`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
  return res.data;
};

export const getCaseDocuments = async (caseId: number): Promise<DocumentItem[]> => {
  const res = await api.get(`/cases/${caseId}/documents`);
  return res.data;
};

export const getDocumentMeta = async (docId: number): Promise<DocumentItem> => {
  const res = await api.get(`/documents/${docId}`);
  return res.data;
};

export const getDocumentPages = async (docId: number) => {
  const res = await api.get(`/documents/${docId}/pages`);
  return res.data;
};

export const queryRag = async (caseId: number, query: string, sessionId: string = 'default') => {
  const formData = new FormData();
  formData.append('case_id', caseId.toString());
  formData.append('query', query);
  formData.append('session_id', sessionId);
  const res = await api.post('/rag/query', formData);
  return res.data;
};

export const getCaseReview = async (caseId: number) => {
  const res = await api.post(`/case-review/${caseId}`);
  return res.data;
};

export const getCaseEvidence = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}/evidence`);
  return res.data;
};

export const getEvidenceGraph = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}/evidence/graph`);
  return res.data;
};

export const getEvidenceCoverage = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}/evidence/coverage`);
  return res.data;
};

export const getContradictions = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}/contradictions`);
  return res.data;
};

export const getMissingInformation = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}/missing-information`);
  return res.data;
};

export const getTimeline = async (caseId: number) => {
  const res = await api.get(`/cases/${caseId}/timeline`);
  return res.data;
};

export const performLegalResearch = async (caseId: number, query: string) => {
  const formData = new FormData();
  formData.append('case_id', caseId.toString());
  formData.append('query', query);
  const res = await api.post('/legal-research', formData);
  return res.data;
};

export const generateLegalDraft = async (caseId: number, title: string, draftType: string, instructions: string) => {
  const formData = new FormData();
  formData.append('case_id', caseId.toString());
  formData.append('title', title);
  formData.append('draft_type', draftType);
  formData.append('instructions', instructions);
  const res = await api.post('/legal-draft', formData);
  return res.data;
};

export const getEvaluationResults = async () => {
  const res = await api.get('/evaluation');
  return res.data;
};

export const runEvaluationSuite = async () => {
  const res = await api.post('/evaluation/run');
  return res.data;
};

export const getPublicHelpResources = async () => {
  const res = await api.get('/public-help');
  return res.data;
};
