import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .database import engine, Base, SessionLocal
from . import models, auth_utils
from .routes import auth, core

# Auto-create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="JURIES PROOF API",
    description="Every legal claim. Every source. Every proof. Evidence-First Agentic Legal Intelligence Platform API",
    version="2.0.0"
)

# Enable CORS for React development server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes under /api
app.include_router(auth.router, prefix="/api")
app.include_router(core.router, prefix="/api")

@app.get("/")
def read_root():
    return {
        "status": "online",
        "platform": "JURIES PROOF — Agentic Legal Intelligence",
        "tagline": "Every legal claim. Every source. Every proof.",
        "pdf_engine": "PyMuPDF (fitz) Local Extraction Operational"
    }

def seed_initial_state():
    db = SessionLocal()
    try:
        user_count = db.query(models.User).count()
        if user_count > 0:
            return

        print("Initializing JURIES PROOF database environment...")
        
        # 1. Create Default Roles & Users
        admin_pwd = auth_utils.get_password_hash("admin123")
        analyst_pwd = auth_utils.get_password_hash("user123")

        admin_user = models.User(
            email="admin@juriesproof.legal",
            hashed_password=admin_pwd,
            role="Admin"
        )
        analyst_user = models.User(
            email="analyst@juriesproof.legal",
            hashed_password=analyst_pwd,
            role="Analyst"
        )

        db.add_all([admin_user, analyst_user])
        db.commit()

        # 2. Seed Initial Operational Legal Sources
        sources = [
            models.LegalSource(
                title="Indian Contract Act, 1872",
                source_type="Statute",
                authority_level="HIGH",
                section_reference="Section 73 (Compensation for loss or damage caused by breach of contract)",
                summary="When a contract has been broken, the party who suffers by such breach is entitled to receive compensation for any loss or damage caused to him thereby.",
                url_or_citation="Act No. 9 of 1872"
            ),
            models.LegalSource(
                title="Evidence Act — Proof of Documentary Evidence",
                source_type="Statute",
                authority_level="HIGH",
                section_reference="Section 61 (Proof of contents of documents)",
                summary="The contents of documents may be proved either by primary or by secondary evidence.",
                url_or_citation="Act No. 1 of 1872"
            ),
            models.LegalSource(
                title="Supreme Court Precedent on Mandatory Performance",
                source_type="Precedent",
                authority_level="HIGH",
                section_reference="Civil Appeal No. 4412/2021",
                summary="Specific performance cannot be granted where factual terms are contradicted across primary evidence exhibits without resolution.",
                url_or_citation="2021 INSC 582"
            )
        ]
        db.add_all(sources)

        # 3. Seed Public Legal Help Resources
        help_items = [
            models.PublicHelpResource(
                title="How to Organize Evidence Before Consulting a Lawyer",
                category="Evidence Preparation",
                content="Compile documents chronologically. Ensure pages are intact and preserve payment receipts, email chains, and signed contracts.",
                official_source="Legal Aid Society Guide"
            ),
            models.PublicHelpResource(
                title="Understanding Contradiction Alerts in Document Evidence",
                category="Document Analysis",
                content="When two documents report different dates or amounts, present both original sources to your legal team without altering timestamps.",
                official_source="JURIES PROOF Evidence Standard"
            ),
            models.PublicHelpResource(
                title="Official Consumer Protection & Legal Helplines",
                category="Official Helplines",
                content="National Legal Services Authority (NALSA): 15100 | Cyber Crime Portal: 1930.",
                official_source="Official Government Helplines"
            )
        ]
        db.add_all(help_items)
        db.commit()

        print("JURIES PROOF initial environment initialized successfully.")
    except Exception as e:
        db.rollback()
        print(f"Database initialization error: {e}")
    finally:
        db.close()

seed_initial_state()
