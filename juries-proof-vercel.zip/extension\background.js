// FastAPI Server Endpoint configuration
const API_URL = "http://localhost:8000/api";

// Initialize local config settings on installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    toggleSafe: true,
    togglePhish: true,
    toggleDownloads: true,
    toggleSync: true
  });
  console.log("Dark Web Watchdog Extension Cores Initialised.");
});

// 1. Intercept file downloads to audit extensions
chrome.downloads?.onCreated.addListener((downloadItem) => {
  chrome.storage.local.get(["toggleDownloads"], (cfg) => {
    if (!cfg.toggleDownloads) return;

    const filename = downloadItem.filename || "";
    const ext = filename.split(".").pop().toLowerCase();
    
    // Malicious/dangerous download targets
    const dangerousExts = ["exe", "bat", "msi", "scr", "cmd", "ps1", "vbs", "jar"];
    if (dangerousExts.includes(ext)) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png", // Falls back to generic Chrome notification icon if missing
        title: "🛡️ Watchdog download Scanner",
        message: `WARNING: Dangerous script file '${filename}' detected! Check origin trust before executing.`,
        priority: 2
      });
      
      // Sync alert back to backend dashboard logs
      syncTelemetryToBackend(new URL(downloadItem.url).hostname, [`Malicious file download blocked: ${filename}`]);
    }
  });
});

// 2. Navigation listener to sync domain visits
chrome.webNavigation?.onCompleted.addListener((details) => {
  // Only intercept main frame loads, skip subframe resource loads
  if (details.frameId !== 0) return;
  
  chrome.storage.local.get(["toggleSync"], (cfg) => {
    if (!cfg.toggleSync) return;

    try {
      const url = new URL(details.url);
      // Skip internal chrome pages
      if (url.protocol.startsWith("chrome")) return;

      // Sync domain visit and reputation check
      checkDomainReputationAndSync(url.hostname);
    } catch (err) {
      console.error(err);
    }
  });
});

// 3. Message receiver for content script credential checking
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkCredentialsSpill") {
    // Content script hashed the email and sent it for checks
    verifyHashSpill(request.emailHash, request.domain);
    sendResponse({ status: "checking" });
  }
  return true;
});

// Fetch reputation and sync domain visit
async function checkDomainReputationAndSync(domain) {
  try {
    const res = await fetch(`${API_URL}/extension/domain?domain=${encodeURIComponent(domain)}`);
    const data = await res.json();
    
    const alerts = [];
    if (data.trust_score < 50) {
      alerts.push(`Low reputation domain visit: ${domain} (Score: ${data.trust_score})`);
    }
    
    await syncTelemetryToBackend(domain, alerts);
  } catch (err) {
    console.log("Failed to sync navigation data to watchdog core server.");
  }
}

// Check hashed email compromise
async function verifyHashSpill(hash, domain) {
  try {
    const res = await fetch(`${API_URL}/extension/check?q=${hash}`);
    const data = await res.json();
    
    if (data.is_compromised) {
      // Trigger instant warning notification
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: "🚨 COMPROMISED EMAIL ALERT",
        message: `Watchdog detected email matching a known spill on '${data.source}'. Reset passwords on ${domain}.`,
        priority: 2
      });

      // Send threat alert notification to user dashboard
      await syncTelemetryToBackend(domain, [`Identity credentials spill match triggered login on ${domain}`]);
    }
  } catch (err) {
    console.log("Failed to check email hash compromise.");
  }
}

// Helper to push extension events to local FastAPI backend logs/alerts
async function syncTelemetryToBackend(domain, alerts = []) {
  try {
    // To identify the user, the sync route requires auth headers or matches active logs.
    // In our prototype backend /extension/sync, we take auth headers if available.
    // If headers aren't sent, we can still parse or sync globally.
    // We will attempt to attach the logged-in user token from local storage (or pass simulated header)
    
    await fetch(`${API_URL}/extension/sync`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        domain: domain,
        alerts: alerts,
        ip_address: "127.0.0.1",
        user_agent: "Chrome Extension Agent"
      })
    });
  } catch (e) {
    console.log("Failed to POST extension telemetry.");
  }
}
