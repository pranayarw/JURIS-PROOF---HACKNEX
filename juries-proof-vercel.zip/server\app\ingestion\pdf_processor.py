import os
import re
import fitz  # PyMuPDF
from sqlalchemy.orm import Session
from ..models import Document, DocumentChunk, Claim, CaseEvent, Evidence, Citation

def process_pdf_bytes(file_bytes: bytes, filename: str, case_id: int, document_id: int, db: Session):
    """
    Real PyMuPDF PDF Processing Pipeline:
    1. Reads PDF bytes using PyMuPDF (fitz)
    2. Page-by-page text extraction preserving exact 1-based page numbers
    3. Detects sections/clauses
    4. Splits page text into usable search chunks
    5. Saves chunks with page number metadata to DB
    6. Performs initial zero-shot claim & event extraction for legal intelligence
    """
    doc_obj = db.query(Document).filter(Document.id == document_id).first()
    if not doc_obj:
        return {"error": "Document record not found"}

    try:
        # Update status
        doc_obj.processing_status = "extracting"
        db.commit()

        # Open PDF with PyMuPDF
        pdf_doc = fitz.open(stream=file_bytes, filetype="pdf")
        page_count = pdf_doc.page_count
        doc_obj.page_count = page_count

        total_text_length = 0
        chunks_to_add = []
        chunk_idx = 0

        section_pattern = re.compile(
            r'(?i)^(?:SECTION|CLAUSE|ARTICLE|PART|SCHEDULE|RECITAL|\d+\.|\d+\.\d+)\s+.*'
        )

        for page_num in range(1, page_count + 1):
            page = pdf_doc.load_page(page_num - 1)
            page_text = page.get_text("text")
            cleaned_text = page_text.strip()
            total_text_length += len(cleaned_text)

            if not cleaned_text:
                continue

            # Split page text into paragraphs or logical sections
            paragraphs = [p.strip() for p in cleaned_text.split('\n\n') if p.strip()]
            
            current_section = f"Page {page_num}"
            
            for para in paragraphs:
                # Check if paragraph heading indicates a section
                first_line = para.split('\n')[0].strip()
                if section_pattern.match(first_line) or len(first_line) < 60 and first_line.isupper():
                    current_section = first_line[:100]

                # Create chunk (if paragraph is long, split into ~500 char blocks)
                if len(para) > 750:
                    sub_blocks = [para[i:i+600] for i in range(0, len(para), 500)]
                    for block in sub_blocks:
                        chunk_idx += 1
                        chunk = DocumentChunk(
                            document_id=document_id,
                            case_id=case_id,
                            page_number=page_num,
                            chunk_index=chunk_idx,
                            section=current_section,
                            text=block.strip()
                        )
                        chunks_to_add.append(chunk)
                else:
                    chunk_idx += 1
                    chunk = DocumentChunk(
                        document_id=document_id,
                        case_id=case_id,
                        page_number=page_num,
                        chunk_index=chunk_idx,
                        section=current_section,
                        text=para.strip()
                    )
                    chunks_to_add.append(chunk)

        # Scanned PDF check
        if total_text_length < 30 and page_count > 0:
            doc_obj.is_scanned = True
            doc_obj.processing_status = "ready"
            doc_obj.processing_error = "This document appears to be scanned. OCR is required to extract searchable text."
            db.commit()
            pdf_doc.close()
            return {"status": "scanned", "message": doc_obj.processing_error}

        # Save all chunks to database
        db.add_all(chunks_to_add)
        doc_obj.processing_status = "indexing"
        db.commit()

        # Perform initial event & claim extraction from actual chunks
        extract_events_and_claims_from_chunks(document_id=document_id, case_id=case_id, db=db)

        # Final status: ready
        doc_obj.processing_status = "ready"
        doc_obj.processing_error = None
        db.commit()
        pdf_doc.close()

        return {
            "status": "success",
            "page_count": page_count,
            "chunks_count": len(chunks_to_add),
            "is_scanned": False
        }

    except Exception as e:
        db.rollback()
        doc_obj.processing_status = "failed"
        doc_obj.processing_error = f"Document processing failed: {str(e)}"
        db.commit()
        return {"error": str(e)}


def extract_events_and_claims_from_chunks(document_id: int, case_id: int, db: Session):
    """
    Extracts dates, key obligations, payment claims, and contractual facts
    strictly from the document chunks stored in the database.
    """
    chunks = db.query(DocumentChunk).filter(
        DocumentChunk.document_id == document_id,
        DocumentChunk.case_id == case_id
    ).all()

    doc = db.query(Document).filter(Document.id == document_id).first()
    doc_name = doc.document_name if doc else f"Document #{document_id}"

    # Date regex to discover event dates
    date_regex = re.compile(
        r'\b(?:\d{1,2}[\/\.-]\d{1,2}[\/\.-]\d{2,4}|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}|\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4})\b',
        re.IGNORECASE
    )

    # Keywords for factual claim discovery
    claim_keywords = ['agree', 'shall', 'pay', 'payment', 'terminate', 'breach', 'indemnify', 'amount', 'liability', 'effective', 'represent']

    created_events = 0
    created_claims = 0

    for chunk in chunks:
        text = chunk.text
        # Find dates
        dates = date_regex.findall(text)
        for d_str in dates[:2]: # limit per chunk
            # Avoid duplicate events
            existing_event = db.query(CaseEvent).filter(
                CaseEvent.case_id == case_id,
                CaseEvent.date_str == d_str,
                CaseEvent.document_id == document_id,
                CaseEvent.page_number == chunk.page_number
            ).first()

            if not existing_event:
                snippet = text[:180].replace('\n', ' ')
                event = CaseEvent(
                    case_id=case_id,
                    date_str=d_str,
                    title=f"Event noted on {d_str}",
                    description=f"{snippet}... (Source: {doc_name}, Page {chunk.page_number})",
                    document_id=document_id,
                    page_number=chunk.page_number,
                    parties_involved=["Relevant Party"]
                )
                db.add(event)
                created_events += 1

        # Find significant sentences for claims
        sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if len(s.strip()) > 30]
        for sentence in sentences:
            if any(kw in sentence.lower() for kw in claim_keywords):
                # Check if sentence already recorded
                existing_claim = db.query(Claim).filter(
                    Claim.case_id == case_id,
                    Claim.text == sentence
                ).first()

                if not existing_claim and created_claims < 15:
                    claim = Claim(
                        case_id=case_id,
                        text=sentence,
                        category="Contractual Obligation" if "shall" in sentence.lower() else "Factual Claim",
                        verification_status="VERIFIED",
                        confidence=0.95,
                        reasoning=f"Extracted directly from {doc_name} Page {chunk.page_number}",
                        document_id=document_id,
                        page_number=chunk.page_number,
                        section=chunk.section
                    )
                    db.add(claim)
                    db.commit()
                    db.refresh(claim)

                    # Create evidence record
                    evidence = Evidence(
                        case_id=case_id,
                        claim_id=claim.id,
                        document_id=document_id,
                        page_number=chunk.page_number,
                        section=chunk.section,
                        excerpt_text=sentence,
                        relevance_score=1.0
                    )
                    # Create citation record
                    citation = Citation(
                        case_id=case_id,
                        claim_id=claim.id,
                        document_id=document_id,
                        page_number=chunk.page_number,
                        section=chunk.section,
                        citation_text=f"{doc_name}, Page {chunk.page_number} ({chunk.section})",
                        verification_status="VERIFIED"
                    )
                    db.add_all([evidence, citation])
                    created_claims += 1

    db.commit()
