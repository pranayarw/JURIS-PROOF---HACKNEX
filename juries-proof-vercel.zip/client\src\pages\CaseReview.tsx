import React, { useEffect, useState } from 'react';
import { FileSearch, CheckCircle2, AlertTriangle, ShieldAlert, FileText, Download } from 'lucide-react';
import { getCaseReview, Case } from '../services/api';

interface CaseReviewProps {
  activeCase: Case | null;
}

export const CaseReviewPage: React.FC<CaseReviewProps> = ({ activeCase }) => {
  const [review, setReview] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeCase) {
      fetchReview();
    }
  }, [activeCase]);

  const fetchReview = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const data = await getCaseReview(activeCase.id);
      setReview(data);
    } catch (err) {
      console.error('Failed to fetch case review:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to view the Case Review.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <FileSearch className="w-5 h-5 text-blue-600" />
            <span>Automated Case Review — {activeCase.case_number}</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Comprehensive grounded analysis generated from real uploaded PDF evidence.
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="flex items-center space-x-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 transition"
        >
          <Download className="w-4 h-4" />
          <span>Export Review</span>
        </button>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-400">
          Analyzing case documents and compiling grounded review...
        </div>
      ) : (
        <div className="space-y-6">
          
          {/* Executive Summary Box */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
              Case Summary
            </h2>
            <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed">
              {review?.summary || 'Case analysis completed across uploaded document exhibits.'}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Evidence Coverage</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  {review?.evidence_coverage?.coverage_percentage ?? 0}%
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Contradictions</span>
                <span className="font-bold text-red-600 dark:text-red-400">
                  {review?.contradictions_count ?? 0}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Missing Info Items</span>
                <span className="font-bold text-amber-600 dark:text-amber-400">
                  {review?.missing_info_count ?? 0}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Source Documents</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {review?.documents?.length ?? 0} PDFs
                </span>
              </div>
            </div>
          </div>

          {/* Key Facts & Source Pages */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
              Key Facts (With Source Citations)
            </h2>

            <div className="space-y-2">
              {review?.key_facts?.length === 0 ? (
                <p className="text-xs text-slate-400 italic">No key facts extracted yet. Upload a PDF document to begin.</p>
              ) : (
                review?.key_facts?.map((item: any, i: number) => (
                  <div key={i} className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700 flex items-start justify-between text-xs">
                    <div className="space-y-1">
                      <p className="font-medium text-slate-800 dark:text-slate-200">"{item.fact}"</p>
                      <span className="text-[10px] text-blue-600 dark:text-blue-400 font-bold block">{item.source}</span>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded text-[10px] font-bold shrink-0">
                      {item.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Important Clauses */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-500 uppercase tracking-wider">
              Important Clauses & Obligations
            </h2>

            <div className="space-y-2">
              {review?.important_clauses?.length === 0 ? (
                <p className="text-xs text-slate-400 italic">No contractual clauses identified in uploaded text.</p>
              ) : (
                review?.important_clauses?.map((item: any, i: number) => (
                  <div key={i} className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                    <div className="flex justify-between text-[10px] font-bold text-slate-500">
                      <span>Clause #{i + 1}</span>
                      <span className="text-blue-600 dark:text-blue-400">{item.section}</span>
                    </div>
                    <p className="font-serif italic text-slate-800 dark:text-slate-200">"{item.clause}"</p>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
