import React, { useEffect, useState } from 'react';
import { HelpCircle, ShieldCheck, AlertCircle, Phone, BookOpen } from 'lucide-react';
import { getPublicHelpResources } from '../services/api';

export const PublicHelpViewPage: React.FC = () => {
  const [resources, setResources] = useState<any[]>([]);

  useEffect(() => {
    fetchHelp();
  }, []);

  const fetchHelp = async () => {
    try {
      const data = await getPublicHelpResources();
      setResources(data);
    } catch (err) {
      console.error('Failed to fetch public help resources:', err);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <HelpCircle className="w-5 h-5 text-blue-600" />
            <span>Public Legal Help & Evidence Guidance</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            General informational resources to assist citizens in organizing legal evidence and connecting with official authorities.
          </p>
        </div>
      </div>

      {/* Mandatory Legal Disclaimer Banner */}
      <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-xl p-5 text-amber-900 dark:text-amber-200 text-xs space-y-2">
        <div className="flex items-center space-x-2 font-bold text-amber-800 dark:text-amber-300 text-sm">
          <AlertCircle className="w-5 h-5 shrink-0 text-amber-600" />
          <span>IMPORTANT LEGAL DISCLAIMER</span>
        </div>
        <p className="leading-relaxed">
          <strong>JURIES PROOF is a prototype for legal document analysis, research assistance, and evidence organization. It does not provide legal advice, does not replace a qualified legal professional, and should not be relied upon as a substitute for professional legal judgment or official legal authorities.</strong>
        </p>
      </div>

      {/* Public Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {resources.map((item) => (
          <div key={item.id} className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between text-[10px] font-bold text-blue-600 uppercase">
              <span>{item.category}</span>
              <BookOpen className="w-3.5 h-3.5" />
            </div>

            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {item.title}
            </h3>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {item.content}
            </p>

            {item.official_source && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 font-medium">
                Official Resource: {item.official_source}
              </div>
            )}
          </div>
        ))}
      </div>

    </div>
  );
};
