import React, { useState } from 'react';
import { 
  MessageSquare, Send, CheckCircle2, AlertTriangle, HelpCircle, 
  FileText, ShieldCheck, CornerDownRight, X, ExternalLink 
} from 'lucide-react';
import { queryRag, Case } from '../services/api';

interface EvidenceChatProps {
  activeCase: Case | null;
  onOpenDocumentViewer?: (docId: number) => void;
}

export const EvidenceChatPage: React.FC<EvidenceChatProps> = ({ activeCase, onOpenDocumentViewer }) => {
  const [messages, setMessages] = useState<any[]>([
    {
      sender: 'assistant',
      message: activeCase 
        ? `Welcome to JURIES PROOF Grounded Q&A for ${activeCase.case_number} (${activeCase.title}). Ask any question regarding payment terms, contractual obligations, dates, or factual claims. All answers are strictly grounded in your uploaded PDF pages.`
        : 'Welcome to JURIES PROOF Grounded Evidence Q&A. Please select an active case to ask evidence-based questions.',
      verification_status: 'VERIFIED',
      citations: [],
      supporting_evidence: []
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [whyModalData, setWhyModalData] = useState<any | null>(null);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !activeCase) return;

    const userText = input.trim();
    setInput('');

    // Append user message
    setMessages((prev) => [
      ...prev,
      { sender: 'user', message: userText }
    ]);

    setLoading(true);
    try {
      const res = await queryRag(activeCase.id, userText);

      setMessages((prev) => [
        ...prev,
        {
          sender: 'assistant',
          message: res.answer,
          verification_status: res.verification_status,
          citations: res.citations || [],
          supporting_evidence: res.supporting_evidence || [],
          missing_info: res.missing_info || [],
          why_explanation: res.why_explanation
        }
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'assistant',
          message: 'Error retrieving case evidence. Please check your backend connection.',
          verification_status: 'INSUFFICIENT EVIDENCE',
          citations: [],
          supporting_evidence: []
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-blue-100 dark:bg-blue-950/60 rounded-lg flex items-center justify-center text-blue-600">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-900 dark:text-white">
              Evidence Q&A / Grounded RAG Chat
            </h1>
            <p className="text-xs text-slate-500">
              {activeCase ? `Scoped to Workspace: ${activeCase.case_number}` : 'Select a case to query uploaded PDFs.'}
            </p>
          </div>
        </div>

        <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-200 dark:border-emerald-800">
          Zero Hallucination Guarantee Active
        </span>
      </div>

      {/* Messages Thread Container */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-4 min-h-[500px] max-h-[650px] overflow-y-auto">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            {msg.sender === 'user' ? (
              <div className="bg-blue-600 text-white rounded-2xl rounded-tr-none px-4 py-2.5 max-w-xl text-xs shadow-sm font-medium">
                {msg.message}
              </div>
            ) : (
              <div className="bg-slate-50 dark:bg-slate-800/90 rounded-2xl rounded-tl-none p-4 max-w-2xl text-xs space-y-3 border border-slate-200 dark:border-slate-700 shadow-sm">
                
                {/* Status Badge */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-4 h-4 text-blue-600" />
                    <span className="font-bold text-slate-700 dark:text-slate-300">JURIES PROOF Response</span>
                  </div>

                  {msg.verification_status === 'INSUFFICIENT EVIDENCE' ? (
                    <span className="px-2.5 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded font-extrabold text-[10px]">
                      INSUFFICIENT EVIDENCE
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded font-extrabold text-[10px]">
                      {msg.verification_status || 'VERIFIED'}
                    </span>
                  )}
                </div>

                {/* Main Response Text */}
                <div className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed font-sans">
                  {msg.message}
                </div>

                {/* Insufficient Evidence Refusal Layout */}
                {msg.verification_status === 'INSUFFICIENT EVIDENCE' && msg.missing_info?.length > 0 && (
                  <div className="bg-amber-50 dark:bg-amber-950/40 p-3 rounded-lg border border-amber-200 dark:border-amber-800 space-y-2 text-amber-900 dark:text-amber-200 text-[11px]">
                    <div className="font-bold flex items-center space-x-1">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                      <span>Missing Information Requirements</span>
                    </div>
                    {msg.missing_info.map((item: any, i: number) => (
                      <div key={i} className="pl-4 space-y-0.5">
                        <p className="font-bold">• Required: {item.item}</p>
                        <p className="text-[10px] text-amber-800 dark:text-amber-300">Reason: {item.reason}</p>
                        <p className="text-[10px] font-semibold text-blue-700 dark:text-blue-300">Recommended Action: {item.recommended_action}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Supporting Evidence Excerpts */}
                {msg.supporting_evidence && msg.supporting_evidence.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Supporting Source Evidence
                    </span>
                    {msg.supporting_evidence.map((ev: any, i: number) => (
                      <div key={i} className="bg-white dark:bg-slate-900 p-2.5 rounded border border-slate-200 dark:border-slate-800 space-y-1">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-bold text-blue-600 dark:text-blue-400">
                            {ev.document_name} — Page {ev.page_number} ({ev.section})
                          </span>
                          <span className="text-slate-400 font-mono">Score: {ev.score}</span>
                        </div>
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 italic font-serif">
                          "{ev.text}"
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Citations & Why? Button Footer */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-700 text-[11px]">
                  <div className="flex items-center space-x-2 text-slate-500">
                    <FileText className="w-3.5 h-3.5" />
                    <span>Citations: {msg.citations?.length || 0} page reference(s)</span>
                  </div>

                  {msg.why_explanation && (
                    <button
                      onClick={() => setWhyModalData(msg.why_explanation)}
                      className="px-2.5 py-1 bg-blue-100 dark:bg-blue-950/80 hover:bg-blue-600 hover:text-white text-blue-700 dark:text-blue-300 rounded font-extrabold text-[11px] transition shadow-xs flex items-center space-x-1"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                      <span>Why?</span>
                    </button>
                  )}
                </div>

              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-center space-x-2 text-xs text-slate-400 italic py-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-ping"></div>
            <span>Searching case document pages and verifying claims...</span>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSend} className="flex items-center space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={activeCase ? "Ask any evidence question about this case..." : "Select an active case first..."}
          disabled={!activeCase || loading}
          className="flex-1 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-3 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          disabled={!activeCase || loading || !input.trim()}
          className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white p-3 rounded-xl shadow transition shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

      {/* "Why?" Evidence Explanation Modal */}
      {whyModalData && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2 text-blue-600">
                <HelpCircle className="w-5 h-5" />
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Why? — Evidence Grounding Chain
                </h2>
              </div>
              <button
                onClick={() => setWhyModalData(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">1. Claim Evaluated</span>
                <span className="font-semibold text-slate-900 dark:text-white">{whyModalData.claim}</span>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">2. Verified Source</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">
                  {whyModalData.source} — Page {whyModalData.page} ({whyModalData.section})
                </span>
              </div>

              {whyModalData.evidence_excerpt && (
                <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">3. Extracted Text Proof</span>
                  <p className="font-serif italic text-slate-800 dark:text-slate-200 mt-1">
                    "{whyModalData.evidence_excerpt}"
                  </p>
                </div>
              )}

              <div className="bg-emerald-50 dark:bg-emerald-950/40 p-3 rounded-lg border border-emerald-200 dark:border-emerald-800">
                <span className="text-[10px] text-emerald-800 dark:text-emerald-300 font-bold uppercase block">4. Verification Logic</span>
                <span className="text-emerald-900 dark:text-emerald-200 font-medium">
                  {whyModalData.reasoning}
                </span>
              </div>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setWhyModalData(null)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-semibold"
              >
                Close Explanation
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
