import React, { useEffect, useState } from 'react';
import { Network, CheckCircle2, ShieldCheck, FileText, Layers, Award } from 'lucide-react';
import { getCaseEvidence, getEvidenceGraph, Case } from '../services/api';

interface EvidenceCenterProps {
  activeCase: Case | null;
}

export const EvidenceCenterPage: React.FC<EvidenceCenterProps> = ({ activeCase }) => {
  const [evidenceData, setEvidenceData] = useState<any>(null);
  const [graphData, setGraphData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeCase) {
      fetchEvidence();
    }
  }, [activeCase]);

  const fetchEvidence = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const ev = await getCaseEvidence(activeCase.id);
      setEvidenceData(ev);
      const graph = await getEvidenceGraph(activeCase.id);
      setGraphData(graph);
    } catch (err) {
      console.error('Failed to fetch evidence data:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case to access the Evidence Center.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <Network className="w-5 h-5 text-blue-600" />
            <span>Evidence Center — Evidence Graph & Verification</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Visualizing relationships between Case Documents, PDF Pages, Extracted Claims, and Verification Status.
          </p>
        </div>
      </div>

      {/* Interactive Evidence Graph Visualization Box */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center space-x-2">
          <Layers className="w-4 h-4 text-blue-600" />
          <span>Interactive Evidence Graph Network</span>
        </h2>

        {/* Visual Graph Node Tree */}
        <div className="bg-slate-50 dark:bg-slate-950/80 rounded-xl p-6 border border-slate-200 dark:border-slate-800 min-h-[350px] flex items-center justify-center">
          {graphData?.nodes?.length === 0 ? (
            <p className="text-xs text-slate-400">No evidence nodes generated yet. Upload a PDF document.</p>
          ) : (
            <div className="w-full space-y-6">
              
              {/* Root Node */}
              <div className="flex justify-center">
                <div className="bg-blue-600 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-md border border-blue-400">
                  Case: {activeCase.case_number} ({activeCase.title})
                </div>
              </div>

              {/* Connecting Lines */}
              <div className="w-0.5 h-6 bg-blue-300 dark:bg-blue-800 mx-auto"></div>

              {/* Document & Claim Nodes Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {graphData?.nodes?.filter((n: any) => n.type !== 'Case').map((node: any, idx: number) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-lg border text-xs space-y-1 ${
                      node.type === 'Document'
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                        : node.type === 'Claim'
                        ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-300 dark:border-blue-800 text-blue-900 dark:text-blue-200'
                        : 'bg-purple-50 dark:bg-purple-950/60 border-purple-300 dark:border-purple-800 text-purple-900 dark:text-purple-200'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-bold">
                      <span>{node.type} Node</span>
                      {node.status && (
                        <span className="px-1.5 py-0.2 bg-white dark:bg-slate-800 rounded">{node.status}</span>
                      )}
                    </div>
                    <p className="font-semibold truncate">{node.label}</p>
                  </div>
                ))}
              </div>

            </div>
          )}
        </div>
      </div>

      {/* Citation Verification Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">Citation Verification Engine</h2>
          <p className="text-xs text-slate-500">Every citation is cross-verified against actual page text extracted by PyMuPDF.</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Citation Reference</th>
                <th className="px-4 py-3">Document</th>
                <th className="px-4 py-3">Page</th>
                <th className="px-4 py-3">Verification Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {evidenceData?.citations?.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-slate-400">
                    No verified citations available for this case yet.
                  </td>
                </tr>
              ) : (
                evidenceData?.citations?.map((cit: any) => (
                  <tr key={cit.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{cit.text}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">Document #{cit.document_id}</td>
                    <td className="px-4 py-3 font-mono font-bold text-blue-600">Page {cit.page_number}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded font-bold text-[10px]">
                        {cit.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
