import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, FilePlus, HelpCircle } from 'lucide-react';
import { getMissingInformation, Case } from '../services/api';

interface MissingInfoViewProps {
  activeCase: Case | null;
}

export const MissingInfoViewPage: React.FC<MissingInfoViewProps> = ({ activeCase }) => {
  const [missingItems, setMissingItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activeCase) {
      fetchMissingInfo();
    }
  }, [activeCase]);

  const fetchMissingInfo = async () => {
    if (!activeCase) return;
    setLoading(true);
    try {
      const data = await getMissingInformation(activeCase.id);
      setMissingItems(data);
    } catch (err) {
      console.error('Failed to fetch missing info:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to view Missing Information tracking.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <span>Missing Information Tracker</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Detects required legal documents, receipts, vouchers, or evidence gaps needed to verify claims.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-400">
          Analyzing case evidence gaps...
        </div>
      ) : missingItems.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-8 rounded-xl border border-slate-200 dark:border-slate-800 text-center space-y-3">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
          <h3 className="text-base font-bold text-slate-900 dark:text-white">All Required Evidence Present</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            No critical evidence gaps or missing information records logged for this case.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {missingItems.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="font-bold text-slate-900 dark:text-white text-sm flex items-center space-x-2">
                  <FilePlus className="w-4 h-4 text-amber-500" />
                  <span>{item.item_name}</span>
                </span>
                <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                  item.priority === 'HIGH'
                    ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}>
                  Priority: {item.priority}
                </span>
              </div>

              <div className="space-y-1 text-xs">
                <span className="text-slate-400 font-bold block text-[10px] uppercase">Why Required</span>
                <p className="text-slate-800 dark:text-slate-200">{item.why_required}</p>
              </div>

              <div className="bg-blue-50 dark:bg-blue-950/40 p-3 rounded-lg border border-blue-200 dark:border-blue-800 text-xs space-y-0.5">
                <span className="font-bold text-blue-900 dark:text-blue-200 block text-[10px] uppercase">Recommended Action</span>
                <p className="text-blue-800 dark:text-blue-300">{item.recommended_action}</p>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
