import React, { useState } from 'react';
import { FileEdit, CheckCircle2, AlertTriangle, Download, Copy, Check } from 'lucide-react';
import { generateLegalDraft, Case } from '../services/api';

interface LegalDraftingProps {
  activeCase: Case | null;
}

export const LegalDraftingPage: React.FC<LegalDraftingProps> = ({ activeCase }) => {
  const [title, setTitle] = useState('Formal Notice of Contract Breach');
  const [draftType, setDraftType] = useState('Notice');
  const [instructions, setInstructions] = useState('Demand immediate settlement for overdue invoice as per contract terms.');
  const [draftResult, setDraftResult] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerateDraft = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCase) return;

    setLoading(true);
    try {
      const data = await generateLegalDraft(activeCase.id, title, draftType, instructions);
      setDraftResult(data);
    } catch (err) {
      console.error('Draft generation failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!draftResult?.content) return;
    navigator.clipboard.writeText(draftResult.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!activeCase) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an active case workspace to generate grounded legal drafts.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
            <FileEdit className="w-5 h-5 text-purple-600" />
            <span>Grounded Legal Drafting Workspace</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Generates formal legal notices and notices using verified case facts. Inserts <code className="bg-amber-100 dark:bg-amber-950 px-1 py-0.5 rounded font-bold text-amber-800 dark:text-amber-300">[INFORMATION REQUIRED]</code> for unverified facts.
          </p>
        </div>
      </div>

      {/* Generator Controls */}
      <form onSubmit={handleGenerateDraft} className="bg-white dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 text-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Document Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Draft Type</label>
            <select
              value={draftType}
              onChange={(e) => setDraftType(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
            >
              <option value="Notice">Legal Notice</option>
              <option value="Contract Summary">Contract Summary</option>
              <option value="Case Summary">Case Brief / Summary</option>
              <option value="Formal Letter">Formal Demand Letter</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Draft Instructions / Context</label>
          <textarea
            rows={2}
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none"
          />
        </div>

        <div className="text-right">
          <button
            type="submit"
            disabled={loading}
            className="bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow transition"
          >
            {loading ? 'Generating Grounded Draft...' : 'Generate Legal Draft'}
          </button>
        </div>
      </form>

      {/* Generated Draft Preview */}
      {draftResult && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <span className="font-bold text-xs text-slate-900 dark:text-white">{draftResult.title}</span>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="flex items-center space-x-1 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
            </div>
          </div>

          <div className="prose dark:prose-invert max-w-none text-xs font-mono whitespace-pre-wrap bg-slate-50 dark:bg-slate-950 p-5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 leading-relaxed">
            {draftResult.content}
          </div>
        </div>
      )}

    </div>
  );
};
